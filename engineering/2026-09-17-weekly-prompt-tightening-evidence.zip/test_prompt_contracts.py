"""Static maintenance regressions, NOT a runtime budget enforcer or semantic judge."""
from pathlib import Path
import re
import unittest

ROOT = Path('/root/.openclaw/workspace')
OUT = ROOT / 'shared/artifacts/weekly-prompt-tightening-20260917'
CRON = Path('/root/.openclaw/agents/main/agent/workshop-skills/cron-run-reliability/SKILL.md')
SKILL = CRON.read_text()
HANDOFF = (ROOT/'shared/prompts/_weekly-report2article-handoff.md').read_text()
INFRA = (ROOT/'shared/prompts/weekly-agent-infra-report.md').read_text()
BEFORE = (OUT/'before/cron-SKILL.md').read_text()

def section(text, heading):
    return text.split(heading,1)[1].split('\n## ',1)[0]

class Contracts(unittest.TestCase):
    def test_01_infra_only_principle_changed(self):
        old=(OUT/'before/infra-prompt.md').read_text()
        strip=lambda t: '\n'.join(x for x in t.splitlines() if not x.startswith('> **总原则**'))
        self.assertEqual(strip(old),strip(INFRA))
        self.assertNotIn('时间充足',INFRA)
        self.assertIn('总时限最长 2 小时',INFRA)
    def test_02_infra_preserves_depth_and_full_scope(self):
        for s in ('保持研究范围、深度与证据标准','8 个 Harness 模块','7 个平台','全文验收和发布','严禁用标题或搜索摘要直接支撑主张'):
            self.assertIn(s,INFRA)
    def test_03_budget_fields_transmitted(self):
        for s in ('deadline_at','checked_at','remaining_seconds','reserve_seconds','委派正文直接传入','唯一负责人和交回条件'):
            self.assertIn(s,SKILL)
    def test_04_budget_math_and_existing_caps(self):
        for s in ('剩余量按父原截止减当前时刻重算','剩余量扣预留后非正','不超过本子可用量的正整数','遵守已有更小上限','不传0'):
            self.assertIn(s,SKILL)
    def test_05_no_invented_deadline_or_reserve(self):
        for s in ('缺截止依据先补合同','无样本则标估计与不确定性','不虚构固定分钟硬闸','非Cron且确无父墙钟截止','不另建回执文件或等待确认循环'):
            self.assertIn(s,SKILL)
    def test_06_recompute_and_quality_not_sacrificed(self):
        self.assertIn('传给接续执行者，不能只留在父级审计',SKILL)
        self.assertIn('时间压力不降低研究准入、全文验收或发布验证要求',SKILL)
    def test_07_done_after_checks_then_final(self):
        done=next(x for x in SKILL.splitlines() if x.startswith('- `.done`'))
        self.assertLess(done.index('自查、版本核对与审计更新'),done.index('再最后写'))
        self.assertLess(done.index('标记写入成功'),done.index('直接返回简短非空final'))
        for s in ('写权交回声明','不再重读全稿','写入失败或发现真实错误','不是父任务质量验收'):
            self.assertIn(s,done)
    def test_08_lifecycle_recovery_guards_unchanged(self):
        starts=('- **恢复顺序**','- 确认原写入者结束','- 文件完整但标记缺失','- 原生重试/重启后','- 总预算不足','- WAIT_TIMEOUT','- 唯一等待命令')
        for prefix in starts:
            a=next(x for x in BEFORE.splitlines() if x.startswith(prefix))
            self.assertIn(a,SKILL)
    def test_09_unaffected_skill_sections_unchanged(self):
        for heading in ('## 适用与读取路由','## 1. 工具与内容边界','## 4. 文章交接','## 5. 配图','## 7. 终态与证据优先级'):
            self.assertEqual(section(BEFORE,heading),section(SKILL,heading))
    def test_10_handoff_reading_and_blindness(self):
        for s in ('context="isolated"','不得接收或读取首次清单、文章内容或编辑线映射','新到的二次清单必须完整读取','此最终验收不可缩成抽样或done检查','协调完成后父级完整读取','全文双向语义与阅读验收'):
            self.assertIn(s,HANDOFF)
    def test_11_handoff_routes_budget_once(self):
        self.assertIn('不以文件路径引用代替实际截止与剩余量',HANDOFF)
        self.assertNotIn('reserve_seconds',HANDOFF)
        self.assertIn('不在此复制字段或另设时限',HANDOFF)
    def test_12_handoff_phase1_and_owner(self):
        for s in ('安全交接成立即由原编辑继续','确需换人按下述写权与恢复规则办理','原写入者已结束','只在原清单补漏区追加','文件交回不证明原生运行或通知成功'):
            self.assertIn(s,HANDOFF)
    def test_13_skill_size_and_reference_paths(self):
        self.assertLess(len(SKILL),10000)
        for link in re.findall(r'\]\(([^)]+)\)',SKILL):
            if not link.startswith(('http:','https:')):
                self.assertTrue((CRON.parent/link.split('#')[0]).exists(),link)
    def test_14_lf_and_eof(self):
        for p in (CRON,ROOT/'shared/prompts/_weekly-report2article-handoff.md',ROOT/'shared/prompts/weekly-agent-infra-report.md'):
            data=p.read_bytes()
            self.assertTrue(data.endswith(b'\n'))
            self.assertNotIn(b'\r',data)
            self.assertFalse(any(x.endswith((b' ',b'\t')) for x in data.splitlines()))

if __name__ == '__main__':
    unittest.main(verbosity=2)
