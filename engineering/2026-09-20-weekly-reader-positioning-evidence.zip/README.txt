七份周报读者定位增强 — 证据包
归档日期: 2026-09-20
产出人: 小帅

内容:
  before/            变更前 8 份 Prompt 原文
  after/             变更后 8 份 Prompt + 新增 _reader-positioning.md
  diff-unified.patch 逐文件 unified diff（纯新增，无删除行）
  SHA256-manifest.txt 变更前后哈希对照
  UPGRADE-RECORD.md  对照归档文档副本

校验结论:
  - 8 份文件全部纯新增，删除 0 行
  - 新增 114 行（diff 中含 8 个 --- 头部标签）
  - 17 个 cron 任务逐字段比对无差异（无新增任务、超时未改）

不含: 任何凭据、API key、调度收件人详情、主机路径凭据。
