# 七主题旧义 → 唯一落点检查表

日期：2026-09-16（Asia/Shanghai）。本表是本次改动审计，不是新增执行规范。

## 1. 唯一所有者与读取路径

- **H（交接）**：`/root/.openclaw/workspace/shared/prompts/_weekly-report2article-handoff.md`。按第二节、第四节定位交接和文章落盘；第一节指定实际已应用的report2article路径。父级正在整合H，本文使用 `owner-versions.json` 所记录且已回读的版本。
- **R（运行）**：`/root/.openclaw/agents/main/agent/workshop-skills/cron-run-reliability/SKILL.md`。第2节身份/版本/写权，第3节等待/恢复，第4—6节仅路由周报专项。
- **P（发布）**：`/root/.openclaw/agents/main/agent/workshop-skills/cron-run-reliability/references/weekly-publication.md`。第4节冻结前格式检查，第5节图片，第6节发布。底层检查参数由其weekly-ops-contract管理，本子任务不复制参数。
- **S/I/L（语义）**：H第一节指定的工作区安装版report2article；此次候选实现分别在普通仓库 `project/skills/report2article/SKILL.md`、`references/info-checklist-template.md`、`references/long-report-protocol.md`。本子任务只改源码，未安装。父级同步后才能以新版规则执行；旧安装版不是已自动生效的新源码。

七Prompt文首保留上述绝对入口及完整读取要求。新短句统一为：

> 文章交接执行文首统一交接协议第二节、第四节；编辑与验收使用协议指定的工作区安装版 `report2article`，等待/恢复只按统一规范第3节。

它是定位引用，不是摘要替代必读，不引入新规范文件、参数、并发或时限。

## 2. 被移出的每项操作要求

下列落点按责任选择一个主定义；上游只作路由，不再在七主题复制长段。S/I/L新版仍须父级完成安装整合，H当前已有同等质量底线。

| 编号 | 旧段独立含义 | 唯一主定义落点 | 核对结论 |
|---|---|---|---|
| U01 | 研究准入后先做冻结前格式预检，再冻结SHA | P第4节“母稿与文章各自在冻结SHA前”；H第二节第3项路由P | 可定位，不删预检、不改检查器参数 |
| U02 | 冻结母稿与公开边界，私密信息不进编辑 | H第二节第3项“冻结公开边界” | PUBLIC/AUDIT/PRIVATE/EVIDENCE四分保留 |
| U03 | 唯一内容输入为最终冻结母稿，不并列历史稿、分片、旧博客 | H第二节第4项首句 | 研究合格和允许公开范围是前提 |
| U04 | 冻结后现有额度内尽早开分离写域双线 | H第二节第4项主段及写域子项 | 冻结前不启动正式提取，既有资源约束保留 |
| U05 | 编辑线先首次清单，再正文/映射 | H第二节第4项编辑线定义；具体编辑步骤由S负责 | 顺序不变 |
| U06 | 盲提取使用context=isolated，只读冻结母稿/边界，不看首清单、文章或编辑映射 | H第二节第4项主段及写域子项 | 输入隔离与独立提取保留 |
| U07 | 资源不足串行但盲提取不混读，不扩并发、不虚构时限 | H第二节第4项资源不足分支 | 不移植资本/具身预算，不增资源 |
| U08 | 两原清单均冻结后才协调，二写者交回；原编辑续做 | H第二节第4项写域子项 | 不互等最终article.done；原计数与唯一写权保留 |
| U09 | 按章节更新traceability当前进度，不等全文后造账本 | H第四节“文章与账本落盘”中traceability及当前进度两项 | 章节进度不等于全刊PASS |
| U10 | 最终完整读三材料及文章，双向语义核验不能机械替代 | H第二节第4项“.done只是交接信号”的最终父级验收；语义判定唯一落S第7节/L第6节 | 中间Phase1与最终父级全文验收明确分开；阅读验收未删除 |
| U11 | 按当前工作区安装版report2article执行，不误用历史副本 | H第一节“report2article负责文章编辑”及绝对路径/SHA约束 | 未将Prompt指向repo源码，不伪称已同步安装 |
| U12 | 中断核SHA、原写者结束，只续未完边界（光谷旧长段额外写明） | R第3节“恢复顺序”及接管条件；输入/规则SHA具体核对在H第四节中断接管项 | 无写者状态证据不能抢写；全量终验不减 |

U10的H条款定义父级交接责任，S/L定义语义验收方法，非两套不同标准；U12的R定义写权/恢复，H仅定义所需输入，后续父级可继续收敛同义细节。

## 3. 七主题逐文件检查

下列路径前缀均为 `/root/.openclaw/workspace/shared/prompts/`。修改仅为原文件的一行内连续操作段；段外内容逐字节一致，原行号和新行号因此相同。旧全文片段、新短句详见 `prompt-replacements.json`；全差异见 `changes.diff`。

| 主题 / 文件 | 旧→新位置 | 已移出操作→唯一落点 | 主题独有内容核对（均未改） |
|---|---|---|---|
| 企业AI / weekly-ai-report.md | L211“准备博客读者稿” | U01—U11 | 企业而非开源项目视角；A—D固定公司/动态新增；NVIDIA和云厂唯一主责；战略/商业化/资本/组织判断；80%/200字/5抽查目标及非硬闸；weekly-ai run目录、A组.done—D组.done、分片两位编号；research/global-ai-weekly及博客basename；INDEX黄山×4+小帅；TOP与企业雷达、标题外壳完整 |
| Agent / weekly-agent-report.md | L213“准备博客读者稿” | U01—U11 | 公司vs产品/项目边界与同事件不同角度双报；4组固定对象/开源筛选/GitHub直查/协议评测权限；80%/200字/5抽查目标；首片组名-日期与后续part两位编号、日期done；research/global-ai-agent-weekly；正文不重复站点标题/头图；INDEX作者不变 |
| Infra / weekly-agent-infra-report.md | L294“准备博客读者稿” | U01—U11 | 原最长2小时；4线覆盖8模块，7平台矩阵所有列；研究前9方向热扫、动态池与过滤条件；OpenViking等固定对象、权限专项、OpenClaw参照；hot-scan-日期与line-A—D.done；250字目标；research/global-ai-agent-infra-weekly、categories:[AI]及图形参数 |
| 产业 / weekly-ai-industry-report.md | L175“博客发布参数” | U01—U11（唯一输入等同时由文首H路由落实） | 原2小时、4组覆盖5行业/全部二级行业/地域；政策全文必要附件、发布日期/生效范围；五维实绩与so-what；原模板、≥15/200字/5抽查目标；research/global-ai-industry-weekly、categories:[AI]、头图日期-ai-industry-weekly-header.png；箭头因果链禁围栏及实际格式自检保留 |
| 资本 / weekly-ai-capital-startup-report.md | L291“博客”操作段 | U01—U11 | 4线单轮，禁止第二轮大规模研究；子90分钟、总4小时/主链路3小时及全部阶段预算/降级顺序不变；S1—7/C1—5、14天背景、候选20—30/深研4—6与9项模板；8000—12000/15000软上限；内部证据包与公开决策稿边界；research/global-ai-capital-startup-weekly、bucket:weekly有条件使用及行动升级条件 |
| 光谷 / weekly-guanggu-report.md | L241“博客发布参数” | U01—U12 | **3组/原2小时**；7板块、三专项各10候选/2深拆/2正文目标；国资/地域/招聘、土地分页和政策附件局限；四类雷达；**news目录、News分类、黄山×3+小帅**；wuhan-guanggu-weekly旧路径及非/news的年月日URL；候选池渲染table、头图固定命令参数保留 |
| 具身 / weekly-embodied-ai-report.md | L256“发布博客”操作段 | U01—U11 | **研究3小时+总4小时**；4组方案A与少信息量父级直做方案B不并行；八环节/适用六维、技术产品20候选/10入口/5深拆/2正文目标；底图与基线→增量→判断→里程碑；技术机制/实验/失效与产品交付/TCO；上限/产能/订单与实绩区别；私密画像边界和建议后置；**旧embodied-ai-opportunity-radar basename、路径URL、连续期号、bucket:embodied**及原头图 |

所有七主题共同保留：原时间窗及同run恢复口径、完整研究模板、来源/归因/风险与必要隐私法律边界、共同证据准出入口、数量目标非机械停刊、research/news路径、原命令全部参数、发布图像限制、非摘要全量保真、四项实际发布验证及非空final的既有约束。

## 4. 机械与人工证据分开

- **精确范围检查**：7/7新文本等于“改前全文只做记录的一次连续替换”；所有其他字节保留。并非只挑几个关键词grep。`before/`存旧字节，`before-manifest.json`、`after-manifest.json`存SHA/行数/字节。
- **语义阅读**：完整读过七旧Prompt；新段逐行回读，与本表U01—U12实际权威条款比对；主题研究/参数未动。最小改动不意味着所有历史措辞已清理：未变的时间/工具说明仍依当前运行时与共享权威解释，本次不借机改参数。
- **独立样本对读**：`semantic-review.md`用19例母稿短记/坏表达检查，不以编号齐平或可解析引用代替语义。
- **未验证范围**：不对七报生产运行效果、速度、外部事实或部署结果签PASS；共享所有者和安装版的最终集成由父级完成。
