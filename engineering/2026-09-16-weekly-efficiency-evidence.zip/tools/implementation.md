# 七份周报效率优化：工具实现与测试交付

交付时间：2026-09-16 14:23（Asia/Shanghai）。

## 1. 结论与范围

**完成 P0-A 的冻结前整文件格式检查及启动前发布参数检查。P0-B 构建复用明确延后，未放宽任何旧构建校验。**

写入范围：

- `/root/.openclaw/workspace/shared/scripts/weekly_ops.py`
- `/root/.openclaw/workspace/shared/scripts/test_weekly_ops.py`
- 本报告所在 `tools/`（测试日志、离线样本、检查输出、diff、代码范围核对）

没有修改 Prompt、Skill、Workshop、配置、排程、权限、模型或两个发布仓库；没有生产研究、构建、HTTP/通知、commit/push。新检查入口不执行任何外部程序。测试中的 Git 仅为隔离临时文件的 `git diff --no-index --check` 判定对照，不对生产仓库执行 Git 操作。

先完整读取现有两个 Python 文件、现行 `weekly-ops-contract.md` 及设计方案，再运行未修改的 **52 项基线回归**。父级备份位于同级 `before/`，本轮未修改备份。

## 2. 实现说明与取舍

### 2.1 `check-inputs`：整文件兼容检查，不改写

保留原来的绝对路径、安全普通文件、无 symlink 父路径、64 MiB 读取上限、读取期间 inode/size/mtime/ctime 稳定、非空 UTF-8、EOF 检查。新增：

- 对每个显式传入文件的**所有行**检查 Git 默认 `blank-at-eol`、`blank-at-eof`、`space-before-tab`。
- 不查 Git 索引，不依赖 diff 范围；新建、未跟踪、尚未拷入仓库的候选文件同样覆盖。调用方仍需枚举所有待冻结文件，不自动扫描整个仓库。
- 任何行的 CRLF、裸 CR 都报告；不再只发现最后一行的 CRLF。
- 问题给出 `code/message/line/column/byte_offset`；行号和列号从 1 起，**column 是字节列，不是 Unicode 字符列**；offset 从 0 起。
- Markdown 双空格硬换行与代码块中的行尾空格一样会被 Git 拒绝，所以一样阻断。提示仅建议唯一写者在核对代码、渲染和语义后人工改写；不自动 `rstrip`、不规范化换行、不去代码缩进/字符串空格，不签语义 PASS。
- 最多展示每文件前 200 个问题，但继续扫描至文件末尾，输出完整 `issue_count` 和 `issues_truncated`，避免错误文件产生无限大的 JSON。
- 按 LF 流式迭代内存中的已读取字节，避免 `split` 为大量空行创建巨型列表。时间为所选文件总字节的线性扫描；不进行全站 hash。

与 Git 的边界：这是固定的 Git 默认空白规则加 LF-only/UTF-8/EOF 合同，不加载 `core.whitespace`、`.gitattributes`、过滤器或平台换行转换。VT、FF、NBSP 不是 Git 默认行尾空白，测试确认不会被扩大为该错误。提交前真实 Git 检查仍必须保留，并覆盖待提交新文件；本工具没有执行 Git，也不保证任意自定义 Git 规则通过。

原 52 项测试中只将一个“合法输入/字节不变”样本里的 `正文<双空格>` 改成 `正文<br>`，原幂等断言不变；新增专门反例证明旧双空格样本现在应 BLOCKED，且字节仍完全不变。

### 2.2 新增 `check-publication-params`，不新增发布执行器

在同一脚本增加只读入口，适合研究启动时检查候选外壳和发布合同，也可针对实际文章复验。不依赖完成的研究母稿、done 标记、图片文件或构建产物；planned 模式不创建目标 post/image。

实际读取并检查：

1. `<blog-repo>/_config.yml` 的 `url/baseurl/permalink/timezone/defaults`。本轮直接核对真实站点配置，当前 permalink 为 `/:year/:month/:day/:title.html`、timezone 为 `Asia/Shanghai`；不把 AI/News 分类猜进文章 URL。
2. `--blog` 必须直接位于 `_posts/`，文件名须是有效日期和小写 ASCII slug；与主题合同提供的 `--expected-basename` 完全一致，不由公开标题推断或改掉具身旧 basename。
3. `--front-matter` 是绝对路径，文件从字节零开始使用 LF `---` 外壳；可为只有外壳的候选文件，也可为完整实际 post。若目标 blog 已存在，读取其 front matter 并要求与候选解析值完全相同。
4. 明示 `layout: single`、非空 title、日期和文件名同日；带时间时只接受 +0800/+08:00；categories 与重复 `--category` 的有序值逐一一致。禁用发布、slug/category 覆盖或未建模的配置元数据 defaults 均阻断。
5. `header.overlay_image` 必须等于 `--header-path`，并是 `/assets/images/posts/<本期日期>-<名称>.<png|jpg|jpeg|webp>`；安全解析本地路径，拒绝符号链接/越界。头图名可独立于文章 slug，保留具身、基础设施、产业等差异；不强制所有历史命名都带 `-header`。
6. 显式 bucket 必须与 `--bucket` 一致，并提供仓库内实际公开源栏目页 `--bucket-page`。栏目页须有一致的 `layout: list`、`list_kind: weekly`、`bucket`、有效 permalink，且不禁用发布；不接受 `_site` 等生成/私有路径或笼统 weekly_all 页。没有 bucket 时两个 bucket 参数都省略，不能用 null 假装字段缺席。
7. 从实际 config 及 basename 或明示静态 post permalink 推导声明 URL，精确对比 `--article-url/--image-url`。拒绝路径穿越、转义路径、query/fragment、远程 permalink、未知路由 token；来源及推导结果写入 `resolved`。
8. 所读文本通过共同的限量、no-follow、普通文件读取；检查末尾重读已观察文本核对 SHA。旧 JSON/审计字符串不是输入接口，不作验证凭据。

**选择有限支持并 fail closed，而不重写 Jekyll。** 仅支持当前 date/title 配置及静态 `.html`/目录型 post permalink。其他站点 permalink、custom source/collections、会改变发布元数据的 defaults、日期/slug 复杂规则、YAML anchors/aliases/merge/重复 key 等不猜测兼容。插件、Liquid、额外 build config、环境覆盖和部署不在此入口执行；其行为须由真实构建和 postbuild/线上验证确认。

bucket 栏目页只能证明**本地栏目元数据一致**，不证明模板已实际收录文章。主题应选哪个 basename/category/bucket 仍由主题权威合同和父级审查决定；helper 不内置七份主题映射、不由 title 猜主题、不判断研究或文章语义。

依赖：此入口懒加载已安装的 **PyYAML 6.0.3**，使用安全加载并拒绝重复 key/别名/显式 tag；单段 YAML 上限 128 KiB、token 上限 8192。缺失 PyYAML 时返回 BLOCKED，不自动安装、不调用 Ruby、不启用猜测解析器；旧 CLI 不依赖 PyYAML。普通文件读取上限仍为 64 MiB。

### 2.3 兼容与构建边界

旧子命令、参数、退出语义均保留；`check-publication` 的 phase 默认仍是 postbuild，缺少构建参数仍 exit 2。新增参数校验是独立入口，旧调用不会被强制加入新的 YAML/配置要求。

对父级备份与当前代码作逐函数 AST 比较（`scope-validation.json`）：

- 既有函数只有 `_inspect_text_file`、`check_inputs`、`main` 发生变化。
- 新增 `_read_stable_bytes`、`_whitespace_issues`、`_yaml_mapping`、`_url_path`、`check_publication_params`。
- `check_publication`、两个旧 validator、`_rendered_blog_path`、`_eof_issue` 等旧函数均保持原 AST。
- 没有修改 freshness 依赖列表，report/article/blog/image/copied-image mtime 仍参与原门控。没有 build 缓存或复用凭证入口。
- 原来要求的真实 build 起止、exit、当前输出及后续验证仍须由发布者记录/提供；不能把本次参数检查时间当 build 开始，也不能把 helper 的 exit 0 当 build exit 0。新结果明列 `real-build-start-end-exit-zero` 为剩余检查。

## 3. 真实 CLI 示例与输出

下列命令已实际执行。除明确说明的只读既有文章检查外，样本全部位于 `tools/fixtures/`，不是生产稿。

### 3.1 冻结前格式检查

```sh
python3 /root/.openclaw/workspace/shared/scripts/weekly_ops.py check-inputs \
  --file /root/.openclaw/workspace/shared/artifacts/weekly-efficiency-implementation-20260916/tools/fixtures/format-blocked.md
```

结果：exit 1，`CHECK_INPUTS_BLOCKED`。`format-blocked.json` 精确报告题头行尾双空格、第二行 CRLF、第四行代码尾空格；文件未被修写。

```sh
python3 /root/.openclaw/workspace/shared/scripts/weekly_ops.py check-inputs \
  --file /root/.openclaw/workspace/shared/artifacts/weekly-efficiency-implementation-20260916/tools/fixtures/format-good.md
```

结果：exit 0，`CHECK_INPUTS_PASS`；`format-good.json`。示例包含代码缩进和字符串内的两个空格，均保持不变。两个样本是独立编写，不是 helper 把前者自动修成后者。

### 3.2 启动前候选外壳（文章和图尚不存在）

```sh
python3 /root/.openclaw/workspace/shared/scripts/weekly_ops.py check-publication-params \
  --blog-repo /root/.openclaw/workspace/project/wujiaming88.github.io \
  --blog _posts/2026-09-17-global-ai-agent-infra-weekly.md \
  --front-matter /root/.openclaw/workspace/shared/artifacts/weekly-efficiency-implementation-20260916/tools/fixtures/startup-front-matter.md \
  --expected-basename 2026-09-17-global-ai-agent-infra-weekly.md \
  --header-path /assets/images/posts/2026-09-17-agent-infra-cover.png \
  --article-url https://wujiaming88.github.io/2026/09/17/global-ai-agent-infra-weekly.html \
  --image-url https://wujiaming88.github.io/assets/images/posts/2026-09-17-agent-infra-cover.png \
  --category AI --bucket agent-infra \
  --bucket-page weekly/agent-infra/index.html
```

结果：exit 0，`PUBLICATION_PARAMS_OK`，`input_mode: planned`，`publication_verified: false`。详见 `startup-params.json`。只读真实站点 config 和栏目源页面，没有创建目标 post/image，也没有构建。

### 3.3 七类既有文章元数据只读烟测

全部精确命令在 `cli-commands.txt`，argv/结果/输入 SHA、mtime、mode 在 `live-parameter-smoke.json`。运行前后所读源文件的这些值一致。

| 样本 | 参数一致性结果 |
|---|---|
| 2026-09-14 AI Agent，categories [AI, Agent] | exit 0 |
| 2026-09-14 光谷，News / guanggu | exit 0 |
| 2026-09-14 全球 AI 动态 | exit 0 |
| 2026-09-15 具身，旧 basename / embodied | exit 0 |
| 2026-09-16 AI 资本与创业，无显式 bucket | exit 0 |
| 2026-09-10 Agent 基础设施，agent-infra | exit 0 |
| 2026-09-11 AI+产业 | **exit 1，正确报告 bucket 不一致** |

AI+产业的实际文章是 `bucket: ai-industry`；`weekly/industry/index.html` 是 `bucket: industry`。本次不擅自映射、忽略、修历史文章或改配置。这个现存差异需父级核对主题合同和站点约定；涉及的修改不在工具交付写域内。6 个 OK 不等于 6 份研究/线上发布验收通过；1 个 BLOCKED 也不是已经证明线上发布失败。

### 3.4 JSON 字段与退出码

`check-inputs` 保留旧状态及 exit 0/1/2：

- 顶层：`status/ok/read_only/semantic_review_performed/limits/files`。
- 新增 `git_check_performed:false`、`whitespace_policy`、`limits.max_issues_per_file:200`。
- `files[]` 保留 `path/ok/sha256/bytes/lines/issues`，新增 `issue_count/issues_truncated`。
- 问题带位置；不安全/缺失路径等无法读取的错误没有虚构位置。
- 单文件 SHA 是实际字节 SHA；格式失败不改变文件。

`check-publication-params`：

- `schema_version:1`，`scope:local-publication-parameters`。
- `status:PUBLICATION_PARAMS_OK`（exit 0）或 `PUBLICATION_PARAMS_BLOCKED`（exit 1）；参数缺失/CLI 用法错误 exit 2。
- `ok/read_only:true/semantic_review_performed:false/publication_verified:false`（ok 按结果变化，其他三个标识不变）。
- `checked`：已完成的局部机械检查；`failures`：首个阻断原因的字符串数组，不宣称聚合全部元数据错误。
- `files`：实际读取路径到 `{sha256, bytes}` 的映射，不是可重放的授权或 build 证据。
- `resolved`：检查进度允许时输出 `blog/input_mode/basename/config_permalink/route_source/article_path/article_url/rendered_relative_path/header_path/header_file/image_url/categories/bucket/site_url/baseurl`。失败时可能为空或只含已推导字段，不得作为准出。
- `remaining_checks`：主题参数权威性、实际 post/image prebuild、运行时路由/真实构建起止与 exit、postbuild、语义、双仓 remote、线上正文/图当前版本；任何本地 OK 都不消除这些检查。

## 4. 精确测试命令与结果

环境：Python 3.10.12，PyYAML 6.0.3，Git 2.34.1。测试使用 `PYTHONDONTWRITEBYTECODE=1`，临时目录全部设置在授权 `tools/tmp/`，不写共享脚本目录的 `__pycache__`。

基线（先于任何代码或测试修改执行）：

```sh
PYTHONDONTWRITEBYTECODE=1 \
TMPDIR=/root/.openclaw/workspace/shared/artifacts/weekly-efficiency-implementation-20260916/tools/tmp \
python3 -m unittest discover \
  -s /root/.openclaw/workspace/shared/scripts -p test_weekly_ops.py -v \
  > /root/.openclaw/workspace/shared/artifacts/weekly-efficiency-implementation-20260916/tools/baseline-tests.log 2>&1
```

真实结果：**Ran 52 tests in 0.845s — OK，exit 0**。

最终回归：

```sh
PYTHONDONTWRITEBYTECODE=1 \
TMPDIR=/root/.openclaw/workspace/shared/artifacts/weekly-efficiency-implementation-20260916/tools/tmp \
python3 -m unittest discover \
  -s /root/.openclaw/workspace/shared/scripts -p test_weekly_ops.py -v \
  > /root/.openclaw/workspace/shared/artifacts/weekly-efficiency-implementation-20260916/tools/tests-final.log 2>&1
```

真实结果：**Ran 88 tests in 2.023s — OK，exit 0，无 skip**。合计增加 36 项：整文件空白 10、发布参数 24、保守构建边界 2；其余 52 项回归保留。

- `PublicationChecklistTests` 共 42 项；新增“仅母稿 mtime 更新仍拒绝旧构建”和“保存 helper OK JSON 不能挽救旧构建”。
- 空白测试覆盖 UTF-8 字节位置、多行聚合、CRLF/裸 CR/EOF、硬换行、fenced/indented code、space-before-tab、200 个问题展示上限、VT/FF/NBSP 不误扩规则。
- Git 对照在临时目录对 `/dev/null` 与新文件执行 `git -c core.whitespace=blank-at-eol,blank-at-eof,space-before-tab -c core.attributesfile=/dev/null diff --no-index --check -- /dev/null <样本>`，屏蔽全局/系统 config 和系统 attributes。helper 自身完全不执行 Git。
- 参数测试覆盖 planned/existing、实际 config 改动、baseurl、静态 permalink、错误分类前缀、旧 basename、多分类、日期时区、头图目录/日期/扩展、bucket 缺失/错名/错栏目、重复 YAML/恶意 tag/alias、缺 PyYAML、UTF-8/BOM/CRLF/限量、symlink/父 symlink/越界/缺失/FIFO、读取中变更和伪造 JSON。
- 参数检查测试把 `subprocess.run/Popen`、`os.system`、`socket.socket` 设为异常，确保新入口不调用执行器或网络；重复检查核对输入 bytes/mtime/mode 不变。
- `source-format.json`：对两个交付 Python 文件运行新 `check-inputs`，exit 0。
- `scope-validation.json`：既有 build/validator 的 AST 保持不变；两个 diff 可直接用于父级审查。

开发过程日志保留：首轮扩展 85 项有 21 个失败（Python 3.10 的 +0800 解析，以及 VT/FF 不属于 Git 默认空白的对照差异）；修正后第二轮 85 项全部通过（1.644s），再增加 3 项边界测试，最终 88 项全通过。日志末尾若见旧 validator 的 FAIL 文本，是故意构造反例的 stdout；以 unittest 总结和进程 exit 为准。

## 5. P0-B 延后：不能证明的事项

本轮不提供 build 指纹、签名、manifest、缓存、复用命令或新构建执行器。没有简单去掉 report mtime，也没有仅 hash 文章后宣布旧 build 可复用。

已看到真实 `_config.yml` 的主题/插件声明、`Gemfile`、本地 `category_generator.rb`，以及根据 `site.posts`、显式 bucket 和文件名进行分类的 Liquid。仅这些已足以说明文章不是唯一依赖；本轮**没有**完成 Ruby/gem/theme/plugin/外部读取的封闭依赖审计，不能证明母稿永远不被间接读取。

| 必须考虑的反例 | 本轮处理与不能证明的边界 |
|---|---|
| config、layout、include、plugin、Gemfile.lock 改动 | 没有完整版本/内容依赖绑定；不允许据新参数 OK 保留旧 build |
| 其他 post、data、静态资产、头图变更 | 可能影响聚合/导航/生成页面；未建模全站依赖，不只 hash 本篇 |
| 输出 HTML/图或其他输出被替换 | 旧 postbuild 有本篇探针/图字节检查，但不是完整输出指纹 |
| 源变更而 mtime 伪旧/被回拨 | 原 mtime 门控不是内容依赖证明；没有把它升级宣称为可信 build 证据 |
| symlink、父路径替换、越界、缺失 | 新入口和原安全边界有反例，但未证明整个 Ruby/Jekyll 依赖图不存在越界/动态读取 |
| build manifest/审计 JSON/缓存证据被篡改 | 没有新增可消费的保存证据；旧 helper 字符串不能授权复用。未声称 SHA 本身可签名认证 |
| 只改非渲染母稿/标记 mtime | 仍按旧逻辑处理，母稿新 mtime 会阻断旧 HTML。done mtime 本来不在该最大值集合中，本轮未改 |
| 真实 build 起止/exit | 未执行 build，不能补造；继续由真实执行记录及当前发布流程提供 |
| 性能代价 | 不新增每轮全站内容 hash，不为依赖“完整”掩盖昂贵扫描；参数检查仅重读少数指定文本 |

因此不满足用户规定的“保守完整真实依赖指纹经反例证明”门槛。延后比引入无法证明的复用路径更安全。现有 local checklist 的 PASS 仍然只是本地检查结果；上述旧机制未覆盖的依赖/mtime 伪旧反例，不能被理解成本轮已经修复。未来若重开 P0-B，应先明确实际构建命令、配置层叠、环境、完整源/输出边界与依赖/运行证据，再单独评估性能和测试，而不是继续累加例外。

## 6. 供父级更新现行契约的完整段落

以下是普通实施报告内的**契约替换/新增文本**，不是 Skill/Workshop 提案；本轮未写入任何 Skill。父级须独立审查后在其授权范围更新现行 `weekly-ops-contract.md` 及调用顺序。

### 6.1 替换 `check-inputs` 三条接口说明

> 一次聚合全部重复 `--file`。每项必须是绝对路径、普通非 symlink、非空有效 UTF-8；从无 symlink 父路径安全打开，读取中 inode/大小/mtime/ctime 保持稳定；每文件最多 64 MiB；EOF 恰好一个 LF，不允许 CRLF、裸 CR 或末尾空白行。对显式传入文件的所有行检查 Git 默认 `blank-at-eol`、`blank-at-eof`、`space-before-tab`，因此覆盖新/未跟踪候选文件，不依赖 Git diff 的可见范围。此入口不执行 Git、不加载仓库自定义空白规则；`CHECK_INPUTS_PASS` 仍不能替代构建前/提交前对真实待提交范围的 Git 检查。
>
> stdout 为单个 JSON：`CHECK_INPUTS_PASS`（exit 0）或 `CHECK_INPUTS_BLOCKED`（exit 1），含 `ok`、`read_only:true`、`semantic_review_performed:false`、`git_check_performed:false`、`whitespace_policy` 和 `limits`；逐文件含 `path/ok/sha256/bytes/lines/issues/issue_count/issues_truncated`。问题给出 code/message 及可取得的精确 line/column/byte_offset；行、字节列从 1 起，字节 offset 从 0 起。每文件最多展示 200 个问题但扫描完整文件，未展示数量由 issue_count 与 issues_truncated 明示。CLI 用法/缺少必需参数由 argparse exit 2。
>
> BLOCKED 只阻止冻结该输入。检查器从不修改、rstrip 或规范化文件。Markdown 合法双空格硬换行也可能与 Git 规则冲突；由唯一写者在当前工作副本人工选择安全表示，并复核受影响渲染、代码空格和语义。代码块、缩进及字符串空格不得批量裁剪。语义未变仅复验受影响边界；语义变化重新内容验收。helper 不签研究、文章或线上业务 PASS。

### 6.2 新增 `check-publication-params` 小节

> `python3 /root/.openclaw/workspace/shared/scripts/weekly_ops.py check-publication-params --blog-repo <站点源根绝对路径> --blog <根内_posts目标路径> --front-matter <候选外壳或实际post绝对路径> --expected-basename <主题规定的含日期.md文件名> --header-path </assets/images/posts/本期图片> --article-url <声明正文完整URL> --image-url <声明图片完整URL> --category <分类> [--category <分类> ...] [--bucket <显式bucket> --bucket-page <实际栏目源页>]`。
>
> 此入口在启动合同明确后检查发布参数，也可在实际外壳生成后复验。只读实际 `<blog-repo>/_config.yml`、候选 front matter、已存在目标 post 的 front matter 及适用的 bucket 栏目源页；不要求 planned post/image 已存在，不创建文件，不执行 build、Git、HTTP、通知或其他外部程序。新增入口依赖已安装 PyYAML，缺失时 BLOCKED，不自动安装；旧 CLI 不依赖 PyYAML。单文件限量读取 64 MiB，单段 YAML 限量 128 KiB，并拒绝重复 key、anchor、alias、merge、显式 tag 及超限 token。
>
> 路径必须安全且不经过 symlink；blog 必须直接位于根内 `_posts/`，basename 必须匹配明确的主题参数及有效 `YYYY-MM-DD-lowercase-ascii-slug.md`。front matter 从字节零以 LF `---` 开始/结束；已有 post 时候选与实际元数据必须一致。明示 layout single、非空 title、与 basename 同日的 date（带时间时 +0800/+08:00）、与重复 category 参数有序一致的 categories；不猜主题、分类或新 basename。
>
> 实际 config 当前只支持 `/:year/:month/:day/:title.html` 与 Asia/Shanghai；可使用安全的静态 post permalink，目录 URL 对应 index.html。未知 config 路由、custom source/collections、会改发布元数据的 defaults、slug/category 覆盖等直接 BLOCKED，不生成猜测分类 URL。正文与图片声明 URL 必须与实际 config url/baseurl 及路径推导一致。header.overlay_image 必须等于声明 header-path，并位于 `/assets/images/posts/`、以文章日期起名且具有受支持图片扩展名；只验路径参数，不在启动阶段冒充图片字节验收。
>
> 存在显式 bucket 时必须传 bucket 及实际公开源 bucket-page；该页的 layout:list、list_kind:weekly、bucket、permalink 必须匹配且不禁用发布，拒绝生成/私有路径及 weekly_all/article 栏目。无 bucket 则两个参数均省略且 front matter 中不含 bucket。栏目元数据一致不是 Liquid 实际收录或线上证明，主题参数本身仍由主题合同和父级审核负责。
>
> stdout 单 JSON 的 schema_version 为 1、scope 为 local-publication-parameters；`PUBLICATION_PARAMS_OK`（exit 0）或 `PUBLICATION_PARAMS_BLOCKED`（exit 1），用法错误 exit 2。含 ok、read_only:true、semantic_review_performed:false、publication_verified:false、checked、failures、files、resolved、remaining_checks。files 为实际文本 SHA/bytes；resolved 可包含 planned/existing 模式、实际配置、basename、正文/图片 URL 与路径、分类/bucket 等。失败时 resolved 可不完整，不能当准出。此入口报告首个阻断，不保证一次枚举所有元数据错误。
>
> OK 只证明本次指定参数与可读取本地配置/外壳的一致性；不签语义或线上 PASS，不证明额外 build config、环境、插件、Liquid、真实渲染、双仓 remote、HTTP 当前版本或投递。启动时可使用候选外壳；实际外壳、头图就位后仍须重新确认参数并执行原 prebuild → 真实 build → postbuild 流程，真实 build 起止/exit 不能由 helper 时间或返回码替代。

### 6.3 在 `check-publication` 构建段补充边界

> 本次只新增冻结前整文件格式检查及启动参数检查，不启用旧 build 复用。check-publication 原有 phase 默认值、参数、正文/归档完整字节比较、done SHA、当前 HTML/图验证及 mtime freshness 门控不变。仅母稿格式或 mtime 变化也不得自行绕过现有门控；保存的 helper JSON、audit PASS、文章单项 SHA 或手工改时间均不是复用依据。真实 build 起止、exit 0、完整渲染依赖及当前输出绑定尚未由完整保守指纹证明前，P0-B 延后，不减发布验证。

## 7. 父级审查入口

- 代码差异：`weekly_ops.diff`（366 行），测试差异：`test_weekly_ops.diff`（468 行）。
- 基线：`baseline-tests.log`；最终回归：`tests-final.log`。
- 功能调用：`format-blocked.json`、`format-good.json`、`startup-params.json`、`cli-commands.txt`。
- 真实配置只读核对：`live-parameter-smoke.json`（6 个参数 OK、1 个 bucket 不一致 BLOCKED；输入未变）。
- 范围/兼容证据：`scope-validation.json`、`source-format.json`。
- 未证明/未交付：安全构建复用、语义验收、线上发布效果、跨七主题自然出刊的效率收益。不能根据本轮单元测试声称已节省生产耗时。
