#!/usr/bin/env python3
from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tempfile
import time
import unittest
from datetime import datetime, timezone
from pathlib import Path
from unittest import mock


MODULE_PATH = Path(__file__).with_name("weekly_ops.py")
SPEC = importlib.util.spec_from_file_location("weekly_ops", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
weekly_ops = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(weekly_ops)


class ValidateBlogPostImageGateTests(unittest.TestCase):
    def make_post(self, root: Path, image_name: str, body: str = "正文\n") -> tuple[Path, Path]:
        image_dir = root / "assets" / "images" / "posts"
        post_dir = root / "_posts"
        image_dir.mkdir(parents=True)
        post_dir.mkdir(parents=True)
        image = image_dir / image_name
        image.write_bytes(b"new-image-bytes")
        post = post_dir / "2026-09-07-example-weekly.md"
        overlay = f"/assets/images/posts/{image_name}"
        post.write_text(
            "---\nlayout: single\nheader:\n  overlay_image: " + overlay + "\n---\n" + body,
            encoding="utf-8",
        )
        return post, image

    def validate(self, root: Path, post: Path) -> int:
        return weekly_ops.validate_blog_post(
            argparse.Namespace(repo=str(root), blog=str(post), site=None)
        )

    def test_accepts_unique_date_named_overlay(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            post, _ = self.make_post(root, "2026-09-07-example-weekly-header.png")
            self.assertEqual(self.validate(root, post), 0)

    def test_rejects_renamed_copy_of_old_image(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            post, image = self.make_post(root, "2026-09-07-example-weekly-header.png")
            old = image.with_name("2026-08-31-example-weekly-header.png")
            old.write_bytes(image.read_bytes())
            self.assertEqual(self.validate(root, post), 1)

    def test_rejects_wrong_date_and_duplicate_body_reference(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            name = "2026-09-06-example-weekly-header.png"
            overlay = f"/assets/images/posts/{name}"
            post, _ = self.make_post(root, name, body=f"![重复头图]({overlay})\n")
            self.assertEqual(self.validate(root, post), 1)


class VisibleFrontMatterTests(unittest.TestCase):
    def check_html(self, fragment: str, expected: int) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            post, image = ValidateBlogPostImageGateTests().make_post(
                root, "2026-09-07-example-weekly-header.png"
            )
            site = root / "site"
            rendered = site / "2026/09/07/example-weekly.html"
            rendered.parent.mkdir(parents=True)
            rendered.write_text(
                '<html><body><img src="/assets/images/posts/' + image.name + '">'
                + fragment + '</body></html>', encoding="utf-8"
            )
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                code = weekly_ops.validate_blog_post(
                    argparse.Namespace(repo=str(root), blog=str(post), site=str(site))
                )
            self.assertEqual(code, expected, output.getvalue())
            if expected:
                self.assertEqual(output.getvalue().splitlines(), [
                    "validate-blog-post: FAIL",
                    "FAIL: blog: raw front matter leaked into rendered HTML",
                ])
            else:
                self.assertTrue(output.getvalue().startswith("validate-blog-post: OK\n"))
                self.assertNotIn("FAIL:", output.getvalue())

    def test_rejects_visible_entities_and_inline_splits(self) -> None:
        samples = {
            "literal": "<p>---\nlayout: single\n---</p>",
            "decimal": "<p>---<br>layout:&#32;single<br>---</p>",
            "hex": "<p>---<br>layout:&#x20;single<br>---</p>",
            "nbsp": "<p>---<br>layout:&nbsp;single<br>---</p>",
            "inline-split": "<p>---<br>lay<span>out:</span> <b>sin</b>gle<br>---</p>",
            "entity-inline": "<div>---</div><div>lay<i>out&#58;</i>&#32;<code>single</code></div><div>---</div>",
            "whitespace": "<p>---<br>\tlayout:   single \t<br>---</p>",
        }
        for name, fragment in samples.items():
            with self.subTest(case=name):
                self.check_html(fragment, 1)

    def test_accepts_nonvisible_and_explanatory_text(self) -> None:
        samples = {
            "script": '<script>const sample = "layout: single";</script>',
            "style": '<style>.sample::after { content: "layout: single"; }</style>',
            "comment": "<!-- ---\nlayout: single\n--- -->",
            "attribute": '<div data-example="layout: single">正文</div>',
            "head": "<head><title>layout: single</title></head>",
            "template": "<template><p>---<br>layout: single<br>---</p></template>",
            "hidden": "<div hidden><div>---<br>layout: single<br>---</div><img></div><p>正文</p>",
            "prose-literal": "<p>本文解释 layout: single 的语法，不是泄漏。</p>",
            "prose-encoded-inline": "<p>可用 <code>layout:&#32;single</code> 选择模板。</p>",
            "different-value": "<p>layout: single-column</p>",
            "escaped-entity": "<p>layout:&amp;#32;single</p>",
        }
        for name, fragment in samples.items():
            with self.subTest(case=name):
                self.check_html(fragment, 0)

    def test_hidden_content_does_not_hide_later_leak(self) -> None:
        for prefix in (
            "<script>ignored</script>",
            "<div hidden><div><br><img>ignored</div></div>",
            "<span hidden/>",
        ):
            with self.subTest(prefix=prefix):
                self.check_html(prefix + "<p>---<br>layout:&#32;single<br>---</p>", 1)


class IndexLinkTargetTests(unittest.TestCase):
    def invoke(self, command: str, root: Path, file: str) -> str:
        args = [command, "--repo", str(root), "--file", " /" + file + " ",
                "--dir", "research", "--author", "作者"]
        if command == "insert-index":
            args += ["--date", "2026-09-12", "--title", "新标题", "--summary", "本周结论。"]
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            self.assertEqual(weekly_ops.main(args), 0)
        return output.getvalue()

    def test_distinct_targets_and_plain_text_do_not_suppress_insert(self) -> None:
        for command in ("insert-index", "insert-index-auto"):
            for kind in ("backup", "prefix", "fragment", "query", "plain-text", "label"):
                with self.subTest(command=command, kind=kind):
                    with tempfile.TemporaryDirectory(prefix="索引 空格 ") as tmp:
                        root = Path(tmp)
                        file = "research/2026-09-12-周报 空格.md"
                        report = root / file
                        report.parent.mkdir()
                        report.write_text("# 新标题\n本周结论。\n", encoding="utf-8")
                        prior = {
                            "backup": f"[备份]({file}.bak)",
                            "prefix": f"[其他](old/{file})",
                            "fragment": f"[片段]({file}#section)",
                            "query": f"[查询]({file}?version=old)",
                            "plain-text": file,
                            "label": f"[{file}](other.md)",
                        }[kind]
                        original = "# INDEX\n\n---\n\n" + prior + "\n"
                        index = root / "INDEX.md"
                        index.write_text(original, encoding="utf-8")
                        first = self.invoke(command, root, file)
                        row = f"| [新标题]({file}) | research | 作者 | 本周结论。 |"
                        after = index.read_bytes()
                        self.assertEqual(first, f"inserted {file} into INDEX.md under 2026-09-12\n")
                        self.assertEqual(index.read_text(encoding="utf-8").count(row), 1)
                        self.assertIn(prior + "\n", index.read_text(encoding="utf-8"))
                        second = self.invoke(command, root, file)
                        self.assertEqual(second, f"index already contains {file}\n")
                        self.assertEqual(index.read_bytes(), after)

    def test_exact_existing_target_is_byte_idempotent_despite_metadata_change(self) -> None:
        for command in ("insert-index", "insert-index-auto"):
            with self.subTest(command=command):
                with tempfile.TemporaryDirectory(prefix="索引 空格 ") as tmp:
                    root = Path(tmp)
                    file = "research/2026-09-12-周报 空格.md"
                    report = root / file
                    report.parent.mkdir()
                    report.write_text("# 新标题\n本周结论。\n", encoding="utf-8")
                    original = f"# INDEX\n\n## 2026-09-05\n| [旧标题]({file}) | 旧目录 | 旧作者 | 旧说明 |\n"
                    index = root / "INDEX.md"
                    index.write_text(original, encoding="utf-8")
                    before = index.read_bytes()
                    for _ in range(2):
                        self.assertEqual(self.invoke(command, root, file), f"index already contains {file}\n")
                        self.assertEqual(index.read_bytes(), before)



class CheckInputsTests(unittest.TestCase):
    def invoke(self, paths: list[Path]) -> tuple[int, dict]:
        output = io.StringIO()
        argv = ["check-inputs"]
        for path in paths:
            argv += ["--file", str(path)]
        with contextlib.redirect_stdout(output):
            code = weekly_ops.main(argv)
        return code, json.loads(output.getvalue())

    def test_unicode_multiple_files_and_byte_idempotency(self) -> None:
        with tempfile.TemporaryDirectory(prefix="输入 空格 ") as tmp:
            root = Path(tmp)
            first = root / "研究.md"
            second = root / "article.txt"
            first.write_bytes("# 标题\n正文<br>\n结论。\n".encode())
            second.write_bytes("```python\n  print('保留缩进')\n```\n".encode())
            before = {p: (p.read_bytes(), p.stat().st_mtime_ns) for p in (first, second)}
            code, result = self.invoke([first, second])
            self.assertEqual(code, 0)
            self.assertEqual(result["status"], "CHECK_INPUTS_PASS")
            self.assertFalse(result["semantic_review_performed"])
            self.assertEqual([item["lines"] for item in result["files"]], [3, 3])
            self.assertEqual(self.invoke([first, second]), (code, result))
            self.assertEqual({p: (p.read_bytes(), p.stat().st_mtime_ns) for p in (first, second)}, before)

    def test_aggregates_utf8_eof_blank_and_valid_results(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            invalid_utf8 = root / "bad-utf8.txt"
            no_lf = root / "no-lf.txt"
            extra_blank = root / "extra.txt"
            crlf = root / "crlf.txt"
            valid = root / "valid.txt"
            invalid_utf8.write_bytes(b"ok\n\xff\n")
            no_lf.write_bytes("正文".encode())
            extra_blank.write_bytes("正文\n \t\n".encode())
            crlf.write_bytes("正文\r\n".encode())
            valid.write_bytes("正常\n".encode())
            code, result = self.invoke([invalid_utf8, no_lf, extra_blank, crlf, valid])
            self.assertEqual(code, 1)
            self.assertEqual(result["status"], "CHECK_INPUTS_BLOCKED")
            self.assertEqual(len(result["files"]), 5)
            codes = [[issue["code"] for issue in item["issues"]] for item in result["files"]]
            self.assertIn("utf8", codes[0])
            self.assertIn("eof", codes[1])
            self.assertIn("eof", codes[2])
            self.assertIn("eof", codes[3])
            self.assertTrue(result["files"][4]["ok"])
            self.assertIn("line", result["files"][1]["issues"][0])

    def test_rejects_empty_directory_fifo_symlink_and_parent_symlink_without_hanging(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            empty = root / "empty.txt"
            empty.write_bytes(b"")
            directory = root / "dir"
            directory.mkdir()
            target = root / "target.txt"
            target.write_bytes(b"target\n")
            link = root / "link.txt"
            link.symlink_to(target)
            real_parent = root / "real-parent"
            real_parent.mkdir()
            nested = real_parent / "nested.txt"
            nested.write_bytes(b"nested\n")
            parent_link = root / "parent-link"
            parent_link.symlink_to(real_parent, target_is_directory=True)
            fifo = root / "pipe"
            os.mkfifo(fifo)
            started = time.monotonic()
            code, result = self.invoke([empty, directory, link, parent_link / "nested.txt", fifo, Path("/dev/null")])
            self.assertEqual(code, 1)
            self.assertLess(time.monotonic() - started, 2.0)
            self.assertEqual(len(result["files"]), 6)
            self.assertTrue(all(not item["ok"] for item in result["files"]))
            self.assertTrue(all({"sha256", "bytes", "lines"} <= item.keys() for item in result["files"]))
            self.assertEqual(result["files"][0]["issues"][0]["code"], "empty")
            self.assertTrue(all(item["issues"] for item in result["files"]))

    def test_rejects_relative_path_and_detects_change_during_read(self) -> None:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            self.assertEqual(weekly_ops.main(["check-inputs", "--file", "relative.txt"]), 1)
        self.assertIn("absolute path required", output.getvalue())
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "race.txt"
            path.write_bytes(b"before\n")
            real_read = os.read
            changed = False
            def mutate_after_read(fd: int, size: int) -> bytes:
                nonlocal changed
                chunk = real_read(fd, size)
                if chunk and not changed:
                    changed = True
                    path.write_bytes(b"after changed\n")
                return chunk
            with mock.patch.object(weekly_ops.os, "read", side_effect=mutate_after_read):
                code, result = self.invoke([path])
            self.assertEqual(code, 1)
            self.assertIn("changed during read", result["files"][0]["issues"][0]["message"])
            path.write_bytes(b"12345")
            with mock.patch.object(weekly_ops, "MAX_TEXT_BYTES", 4):
                code, result = self.invoke([path])
            self.assertEqual(code, 1)
            self.assertIn("bounded read limit", result["files"][0]["issues"][0]["message"])

class PublicationChecklistTests(unittest.TestCase):
    """Synthetic local fixtures only; no production run/repository/network."""

    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory(prefix="双仓 空格 ")
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.run = self.root / "run"
        self.run.mkdir()
        self.archive = self.root / "archive"
        self.archive.mkdir()
        self.repo = self.root / "blog"
        self.repo.mkdir()
        self.post, self.image = ValidateBlogPostImageGateTests().make_post(
            self.repo, "2026-09-07-example-weekly-header.png", body="# 本期标题\n本周独立结论。\n"
        )
        self.report = self.run / "report.md"
        self.report.write_text("# 母稿\n本周独立结论与研究证据。\n", encoding="utf-8")
        self.article = self.run / "article.md"
        self.article.write_text("# 本期标题\n本周独立结论。\n", encoding="utf-8")
        self.frozen_image = self.run / "header.png"
        self.frozen_image.write_bytes(self.image.read_bytes())
        self.target = self.archive / "research/2026-09-07-周报.md"
        self.target.parent.mkdir()
        self.target.write_bytes(self.report.read_bytes())
        self.index = self.archive / "INDEX.md"
        self.index.write_text(
            "# INDEX\n\n## 2026-09-07\n| [周报](research/2026-09-07-周报.md) | research | 作者 | 说明 |\n",
            encoding="utf-8",
        )
        self.research_done = self.run / "research.done"
        self.article_done = self.run / "article.done"
        self.write_done()
        self.site = self.repo / "current-build"
        self.html = self.site / "2026/09/07/example-weekly.html"
        self.html.parent.mkdir(parents=True)
        self.html.write_text(
            '<html><body><h1>本期标题</h1><p>本周独立结论。</p><img src="/assets/images/posts/'
            + self.image.name + '"></body></html>', encoding="utf-8"
        )
        self.built_image = self.site / "assets/images/posts" / self.image.name
        self.built_image.parent.mkdir(parents=True)
        self.built_image.write_bytes(self.image.read_bytes())
        # Deliberate ordering, not sleeps or interpreter-startup timing.
        self.start = time.time() - 30
        for path in self.root.rglob("*"):
            if path.is_file():
                stamp = self.start + 10 if self.site in path.parents else self.start - 10
                os.utime(path, (stamp, stamp))
        self.build_time = datetime.fromtimestamp(self.start, timezone.utc).isoformat()
        self.addCleanup(mock.patch.stopall)
        mock.patch.object(weekly_ops.subprocess, "run", side_effect=AssertionError("no executor allowed in fixture")).start()
        mock.patch("socket.create_connection", side_effect=AssertionError("no network allowed")).start()

    def write_done(self) -> None:
        source_hash = hashlib.sha256(self.report.read_bytes()).hexdigest()
        common = f"status: PASS\nrun_id: run-current\nsource_sha256: {source_hash}\n"
        self.research_done.write_text(common, encoding="utf-8")
        self.article_done.write_text(
            common + "article_sha256: " + hashlib.sha256(self.article.read_bytes()).hexdigest() + "\n",
            encoding="utf-8",
        )

    def argv(self) -> list[str]:
        return [
            "check-publication", "--run-id", "run-current",
            "--research-done", str(self.research_done), "--article-done", str(self.article_done),
            "--report", str(self.report), "--article", str(self.article),
            "--archive-repo", str(self.archive), "--archive-file", "research/2026-09-07-周报.md",
            "--index-date", "2026-09-07", "--blog-repo", str(self.repo), "--blog", str(self.post),
            "--image", str(self.frozen_image), "--site", str(self.site),
            "--build-started-at", self.build_time,
            "--html-text", "本期标题", "--html-text", "本周独立结论。",
        ]

    def check(self, expected: int = 1, reason: str = "", argv: list[str] | None = None) -> dict:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = weekly_ops.main(argv or self.argv())
        self.assertEqual(code, expected, output.getvalue())
        result = json.loads(output.getvalue())
        self.assertEqual(result["ok"], expected == 0)
        self.assertEqual(result["scope"], "local-publication-checklist")
        self.assertEqual(result["publication_verified"], False)
        self.assertIn("git-remote-both-repos", result["remaining_checks"])
        if reason:
            self.assertIn(reason, " ".join(result["failures"]))
        return result

    def test_valid_fixture_and_repeat_are_read_only(self) -> None:
        def snapshot() -> dict:
            return {str(p): (p.read_bytes(), p.stat().st_mtime_ns, p.stat().st_mode)
                    for p in self.root.rglob("*") if p.is_file()}
        before = snapshot()
        first = self.check(0)
        second = self.check(0)
        self.assertEqual(first, second)
        self.assertEqual(snapshot(), before)
        self.assertEqual(first["status"], "LOCAL_CHECKLIST_PASS")

    def test_blog_only_success_and_forged_audit_do_not_pass(self) -> None:
        self.target.unlink()
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(weekly_ops.validate_blog_post(
                argparse.Namespace(repo=str(self.repo), blog=str(self.post), site=str(self.site))
            ), 0)
        (self.run / "audit.md").write_text(
            "archive: PASS\nblog: PASS\nGit: PASS\nHTTP: PASS\nbusiness: SUCCESS\n", encoding="utf-8"
        )
        self.check(reason="archive-file")

    def test_missing_index(self) -> None:
        self.index.unlink()
        self.check(reason="INDEX")

    def test_index_requires_exact_table_link_in_expected_date(self) -> None:
        target = "research/2026-09-07-周报.md"
        cases = [target, f"[{target}](other.md)", f"[周报]({target})",
                 f"| [周报]({target}.bak) |", f"| [周报]({target}#part) |",
                 f"| [周报]({target}?v=old) |", f"<!-- | [周报]({target}) | -->",
                 f"```\n| [周报]({target}) |\n```",
                 f"## 2026-08-31\n| [周报]({target}) |"]
        for row in cases:
            with self.subTest(row=row):
                self.index.write_text("## 2026-09-07\n" + row + "\n", encoding="utf-8")
                self.check(reason="INDEX entry")

    def test_wrong_run_id_in_either_done(self) -> None:
        for path in (self.research_done, self.article_done):
            with self.subTest(path=path.name):
                self.write_done()
                path.write_text(path.read_text().replace("run-current", "run-old"), encoding="utf-8")
                self.check(reason="run_id")

    def test_blocked_or_ambiguous_done_is_rejected(self) -> None:
        for value in ("status: BLOCKED", "status: PASS\nstatus: BLOCKED", "status: PASS\nstatus: PASS",
                      "status: RUNNING", "status: PASS\nprevious: BLOCKED"):
            with self.subTest(value=value):
                self.write_done()
                self.article_done.write_text(self.article_done.read_text().replace("status: PASS", value), encoding="utf-8")
                self.check(reason="article.done")

    def test_missing_done(self) -> None:
        self.research_done.unlink()
        self.check(reason="research.done")

    def test_changed_source_invalidates_done(self) -> None:
        self.report.write_bytes(self.report.read_bytes() + b"new version\n")
        self.target.write_bytes(self.report.read_bytes())
        self.check(reason="source_sha256")

    def test_wrong_article_source_hash(self) -> None:
        text = self.article_done.read_text()
        self.article_done.write_text(text.replace(hashlib.sha256(self.report.read_bytes()).hexdigest(), "0" * 64), encoding="utf-8")
        self.check(reason="source_sha256")

    def test_changed_article_invalidates_done(self) -> None:
        self.article.write_bytes(self.article.read_bytes() + b"new version\n")
        self.check(reason="article_sha256")

    def test_archive_must_equal_frozen_report_bytes(self) -> None:
        self.target.write_bytes(self.report.read_bytes() + b"\n")
        self.check(reason="archive bytes")

    def test_blog_body_must_equal_frozen_article_bytes(self) -> None:
        self.post.write_text(self.post.read_text().replace("本周独立结论。", "只有摘要。"), encoding="utf-8")
        self.check(reason="blog body")

    def test_missing_or_different_header(self) -> None:
        original = self.image.read_bytes()
        for content in (None, b"", b"wrong-image"):
            with self.subTest(content=content):
                if content is None:
                    self.image.unlink()
                else:
                    self.image.write_bytes(content)
                self.check(reason="image")
                self.image.write_bytes(original)

    def test_duplicate_old_header_still_rejected_by_existing_validator(self) -> None:
        self.image.with_name("2026-08-31-old.png").write_bytes(self.image.read_bytes())
        self.check(reason="duplicates")

    def test_requires_html_from_specified_site_not_another_old_site(self) -> None:
        wrong_site = self.repo / "another-build"
        wrong_site.mkdir()
        argv = self.argv()
        argv[argv.index("--site") + 1] = str(wrong_site)
        self.check(reason="rendered HTML", argv=argv)

    def test_old_build_rejected_even_if_content_matches(self) -> None:
        stamp = self.start - 20
        os.utime(self.html, (stamp, stamp))
        self.check(reason="build freshness")

    def test_nonrendering_master_mtime_still_invalidates_build_no_reuse_enabled(self) -> None:
        os.utime(self.report, (self.start + 20, self.start + 20))
        self.check(reason="build freshness")

    def test_saved_helper_result_does_not_override_stale_build(self) -> None:
        (self.run / "cached-helper.json").write_text(json.dumps(self.check(0)), encoding="utf-8")
        os.utime(self.html, (self.start - 20, self.start - 20))
        self.check(reason="build freshness")

    def test_source_changed_after_build_rejected(self) -> None:
        stamp = self.start + 20
        os.utime(self.post, (stamp, stamp))
        self.check(reason="build freshness")

    def test_build_timestamp_requires_timezone_and_not_future(self) -> None:
        for stamp in ("invalid", "2026-09-14T13:00:00", "2999-01-01T00:00:00+08:00"):
            with self.subTest(stamp=stamp):
                argv = self.argv()
                argv[argv.index("--build-started-at") + 1] = stamp
                self.check(reason="build-started-at", argv=argv)

    def test_old_html_with_current_timestamp_rejected_by_content_probe(self) -> None:
        self.html.write_text(self.html.read_text().replace("本周独立结论。", "上期结论。"), encoding="utf-8")
        self.check(reason="HTML text")

    def test_html_probe_must_be_visible_not_comment_or_script(self) -> None:
        for fragment in ("<!-- 本周独立结论。 -->", "<script>本周独立结论。</script>"):
            with self.subTest(fragment=fragment):
                self.html.write_text('<img src="/assets/images/posts/' + self.image.name
                                     + '"><h1>本期标题</h1>' + fragment, encoding="utf-8")
                self.check(reason="HTML text")

    def test_probe_must_come_from_article(self) -> None:
        argv = self.argv() + ["--html-text", "unrelated"]
        self.check(reason="article probe", argv=argv)

    def test_rendered_front_matter_gate_is_reused(self) -> None:
        self.html.write_text(self.html.read_text() + "<p>layout:&#32;single</p>", encoding="utf-8")
        self.check(reason="front matter leaked")

    def test_built_header_must_exist_and_match(self) -> None:
        self.built_image.unlink()
        self.check(reason="built image")
        self.built_image.write_bytes(b"old image")
        self.check(reason="built image bytes")

    def test_delivery_pending_and_native_failed_do_not_erase_business_files(self) -> None:
        for path in (self.article_done, self.research_done):
            path.write_text(path.read_text() + "delivery: PENDING\nnative_status: failed\n", encoding="utf-8")
        self.check(0)

    def test_rejects_symlink_or_escape_in_repository_paths(self) -> None:
        self.target.unlink()
        self.target.symlink_to(self.report)
        self.check(reason="symlink")
        argv = self.argv()
        argv[argv.index("--archive-file") + 1] = str(self.report)
        self.check(reason="outside", argv=argv)

    def test_malformed_utf8_is_reported_not_a_traceback(self) -> None:
        self.article_done.write_bytes(b"\xff\xfe")
        self.check(reason="UTF-8")

    def test_each_required_source_is_nonempty_regular_file(self) -> None:
        for path, label in ((self.report, "report"), (self.article, "article"),
                            (self.post, "blog"), (self.frozen_image, "frozen image")):
            original = path.read_bytes()
            for kind in ("missing", "empty", "directory"):
                with self.subTest(path=path.name, kind=kind):
                    path.unlink()
                    if kind == "empty":
                        path.write_bytes(b"")
                    elif kind == "directory":
                        path.mkdir()
                    self.check(reason=label)
                    if path.is_dir():
                        path.rmdir()
                    path.write_bytes(original)
                    os.utime(path, (self.start - 10, self.start - 10))

    def test_done_required_fields_cannot_be_missing_or_duplicated(self) -> None:
        for field in ("status", "run_id", "source_sha256", "article_sha256"):
            for kind in ("missing", "duplicate"):
                with self.subTest(field=field, kind=kind):
                    self.write_done()
                    lines = self.article_done.read_text().splitlines(keepends=True)
                    selected = next(line for line in lines if line.startswith(field + ":"))
                    text = "".join(line for line in lines if line != selected) if kind == "missing" else "".join(lines) + selected
                    self.article_done.write_text(text, encoding="utf-8")
                    self.check(reason=field)

    def test_accepted_permalink_build_path(self) -> None:
        self.post.write_text(self.post.read_text().replace("layout: single\n", "layout: single\npermalink: /weekly/current/\n"), encoding="utf-8")
        os.utime(self.post, (self.start - 10, self.start - 10))
        new_html = self.site / "weekly/current/index.html"
        new_html.parent.mkdir(parents=True)
        self.html.rename(new_html)
        self.check(0)

    def test_permalink_and_overlay_cannot_escape_roots(self) -> None:
        original = self.post.read_text()
        self.post.write_text(original.replace("layout: single\n", "layout: single\npermalink: /../../escaped/\n"), encoding="utf-8")
        self.check(reason="outside")
        self.post.write_text(original.replace("/assets/images/posts/", "/assets/images/posts/../../../../"), encoding="utf-8")
        self.check(reason="outside")

    def test_optional_kramdown_table_failure_still_blocks(self) -> None:
        with mock.patch.object(weekly_ops, "_count_rendered_tables", return_value=(1, 0, 1)) as tables:
            self.check(reason="table render mismatch")
            self.assertTrue(tables.called)

    def test_mutation_observed_during_check_is_rejected(self) -> None:
        def changed_source(_args: argparse.Namespace) -> int:
            self.target.write_bytes(b"changed during inspection")
            return 0
        with mock.patch.object(weekly_ops, "validate_blog_post", side_effect=changed_source):
            self.check(reason="input changed during checklist")

    def test_roots_cannot_be_same_or_nested(self) -> None:
        for root in (self.repo, self.repo / "assets"):
            with self.subTest(root=root):
                argv = self.argv()
                argv[argv.index("--archive-repo") + 1] = str(root)
                self.check(reason="non-overlapping", argv=argv)

    def test_empty_probe_is_not_version_evidence(self) -> None:
        self.check(reason="article probe", argv=self.argv() + ["--html-text", "  "])

    def test_help_is_real_and_required_flags_are_enforced(self) -> None:
        output = io.StringIO()
        with contextlib.redirect_stdout(output), self.assertRaises(SystemExit) as ctx:
            weekly_ops.main(["check-publication", "--help"])
        self.assertEqual(ctx.exception.code, 0)
        self.assertIn("--build-started-at", output.getvalue())
        self.assertIn("--html-text", output.getvalue())
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as ctx:
            weekly_ops.main(["check-publication"])
        self.assertEqual(ctx.exception.code, 2)


    def prebuild_argv(self) -> list[str]:
        legacy = self.argv()
        result = [legacy[0], "--phase", "prebuild"]
        skip_value = False
        for item in legacy[1:]:
            if skip_value:
                skip_value = False
                continue
            if item in ("--site", "--build-started-at", "--html-text"):
                skip_value = True
                continue
            result.append(item)
        return result

    def test_prebuild_passes_without_site_and_does_not_claim_publication(self) -> None:
        argv = self.prebuild_argv()
        self.assertNotIn("--site", argv)
        result = self.check(0, argv=argv)
        self.assertEqual(result["phase"], "prebuild")
        self.assertEqual(result["status"], "LOCAL_SOURCE_CHECKLIST_PASS")
        self.assertFalse(result["publication_verified"])
        self.assertIn("postbuild-local-checklist", result["remaining_checks"])
        self.assertNotIn("rendered HTML", " ".join(result["checked"]))

    def test_prebuild_rejects_source_eof_before_build(self) -> None:
        self.report.write_bytes(self.report.read_bytes() + b"\n")
        self.target.write_bytes(self.report.read_bytes())
        self.write_done()
        result = self.check(reason="EOF", argv=self.prebuild_argv())
        self.assertEqual(result["status"], "LOCAL_SOURCE_CHECKLIST_BLOCKED")

    def test_prebuild_rejects_missing_or_changed_sha_archive_and_body(self) -> None:
        original_done = self.article_done.read_text()
        self.article_done.write_text(original_done.replace("article_sha256:", "old_article_sha256:"), encoding="utf-8")
        self.check(reason="article_sha256", argv=self.prebuild_argv())
        self.article_done.write_text(original_done.replace(hashlib.sha256(self.article.read_bytes()).hexdigest(), "0" * 64), encoding="utf-8")
        self.check(reason="article_sha256", argv=self.prebuild_argv())
        self.article_done.write_text(original_done, encoding="utf-8")
        self.target.write_bytes(self.report.read_bytes() + b"different\n")
        self.check(reason="archive bytes", argv=self.prebuild_argv())
        self.target.write_bytes(self.report.read_bytes())
        self.post.write_text(self.post.read_text().replace("本周独立结论。", "正文不同。"), encoding="utf-8")
        self.check(reason="blog body", argv=self.prebuild_argv())

    def test_prebuild_runs_blog_format_validator(self) -> None:
        changed = self.article.read_text().replace("本周独立结论。", "本周独立结论。 TODO")
        self.article.write_text(changed, encoding="utf-8")
        front = self.post.read_text().split("\n---\n", 1)[0] + "\n---\n"
        self.post.write_text(front + changed, encoding="utf-8")
        self.write_done()
        self.check(reason="TODO-like placeholder", argv=self.prebuild_argv())

    def test_postbuild_missing_build_arguments_exit_two_and_default_is_legacy(self) -> None:
        full = self.argv()
        for missing_flag in ("--site", "--build-started-at", "--html-text"):
            argv: list[str] = []
            skip_value = False
            for item in full:
                if skip_value:
                    skip_value = False
                    continue
                if item == missing_flag:
                    skip_value = True
                    continue
                argv.append(item)
            with self.subTest(flag=missing_flag):
                with contextlib.redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit) as raised:
                        weekly_ops.main(argv)
                self.assertEqual(raised.exception.code, 2)
        result = self.check(0, argv=full)
        self.assertEqual(result["phase"], "postbuild")
        self.assertEqual(result["status"], "LOCAL_CHECKLIST_PASS")


class WholeFileWhitespaceTests(unittest.TestCase):
    def inspect(self, data: bytes) -> dict:
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "untracked.md"
            path.write_bytes(data)
            before = (path.read_bytes(), path.stat().st_mtime_ns, path.stat().st_mode)
            result = weekly_ops._inspect_text_file(str(path))
            self.assertEqual((path.read_bytes(), path.stat().st_mtime_ns, path.stat().st_mode), before)
            return result

    def test_untracked_middle_lines_exact_byte_locations_and_manual_hint(self) -> None:
        result = self.inspect("题头  \n正文\t\n结尾。\n".encode())
        self.assertFalse(result["ok"])
        issues = result["issues"]
        self.assertEqual([(i["code"], i["line"], i["column"], i["byte_offset"]) for i in issues],
                         [("blank-at-eol", 1, 7, 6), ("blank-at-eol", 2, 7, 15)])
        self.assertIn("hard break", issues[0]["hint"])
        self.assertIn("never blanket-rstrip", issues[0]["hint"])

    def test_crlf_on_interior_lines_even_with_final_lf(self) -> None:
        result = self.inspect(b"first\r\nsecond\nlast\n")
        self.assertFalse(result["ok"])
        self.assertEqual([(i["code"], i["line"], i["column"], i["byte_offset"]) for i in result["issues"]],
                         [("crlf", 1, 6, 5)])
        result = self.inspect(b"first\r\nlast\r\n")
        self.assertEqual([i["line"] for i in result["issues"] if i["code"] == "crlf"], [1, 2])

    def test_bare_cr_and_missing_final_lf_are_reported(self) -> None:
        result = self.inspect(b"a\rb\nc\r")
        self.assertEqual([i["line"] for i in result["issues"] if i["code"] == "carriage-return"], [1, 2])
        self.assertIn("eof", [i["code"] for i in result["issues"]])
        self.assertFalse(self.inspect(b"a")["ok"])

    def test_blank_eof_range_starts_at_first_trailing_blank(self) -> None:
        for ending in (b"\n\n", b"\n \t\n\n", b"\n\t\n \n"):
            with self.subTest(ending=ending):
                result = self.inspect(b"body" + ending)
                blank = next(i for i in result["issues"] if i["code"] == "blank-at-eof")
                self.assertEqual((blank["line"], blank["byte_offset"]), (2, 5))
        self.assertTrue(self.inspect(b"body\n\nnext\n")["ok"])

    def test_space_before_tab_only_in_indentation(self) -> None:
        result = self.inspect(b" \tcode\n\t \tcode\nbody \t middle\n")
        self.assertEqual([(i["line"], i["column"]) for i in result["issues"] if i["code"] == "space-before-tab"],
                         [(1, 1), (2, 2)])

    def test_code_whitespace_flagged_but_never_rewritten(self) -> None:
        result = self.inspect(b"```python\n    value = '  '\n    print(value)  \n```\n\n    indented code \t\nend\n")
        self.assertFalse(result["ok"])
        self.assertEqual([i["line"] for i in result["issues"] if i["code"] == "blank-at-eol"], [3, 6])
        self.assertTrue(self.inspect(b"```python\n    value = '  '\n\tprint(value)\n```\n")["ok"])

    def test_intentional_markdown_breaks_not_exempt_from_git_rule(self) -> None:
        for data in (b"paragraph  \nnext\n", b"paragraph   \nnext\n", b"# heading  \nnext\n"):
            with self.subTest(data=data):
                self.assertFalse(self.inspect(data)["ok"])
        for data in (b"paragraph<br>\nnext\n", b"paragraph\\\nnext\n"):
            with self.subTest(data=data):
                self.assertTrue(self.inspect(data)["ok"])

    def test_ascii_space_tab_rejected_but_git_nonwhitespace_preserved(self) -> None:
        for suffix in (b" ", b"\t", b" \t"):
            with self.subTest(suffix=suffix):
                self.assertIn("blank-at-eol", [i["code"] for i in self.inspect(b"text" + suffix + b"\nend\n")["issues"]])
        for suffix in (b"\v", b"\f", "\u00a0".encode()):
            with self.subTest(suffix=suffix):
                self.assertTrue(self.inspect(b"text" + suffix + b"\nend\n")["ok"])

    def test_issues_are_bounded_without_skipping_full_scan(self) -> None:
        result = self.inspect(b"bad \n" * 350 + b"good\n")
        self.assertFalse(result["ok"])
        self.assertEqual(result["issue_count"], 350)
        self.assertEqual(len(result["issues"]), weekly_ops.MAX_TEXT_ISSUES)
        self.assertTrue(result["issues_truncated"])

    @unittest.skipUnless(shutil.which("git"), "Git oracle unavailable; helper itself never executes Git")
    def test_matches_actual_git_default_whitespace_rejections_on_whole_new_files(self) -> None:
        samples = [b"ok\n", b"hard break  \nnext\n", b"tab\t\nend\n", b"a\v\nend\n", b"a\f\nend\n",
                   b"a\r\nend\n", b"a\n\n", b"a\n \t\n", b" \tcode\n", b"\t \tcode\n",
                   b"body \t middle\n", b"a\n", b"a", b"a\r", b"a\n\t", b"```\ncode  \n```\n"]
        # No repo/index/global attributes: --no-index compares /dev/null with the
        # entire untracked file. This is a test oracle, not helper execution.
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "new.md"
            env = {**os.environ, "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull,
                   "GIT_ATTR_NOSYSTEM": "1", "LC_ALL": "C"}
            for data in samples:
                with self.subTest(data=data):
                    path.write_bytes(data)
                    proc = subprocess.run(["git", "-c", "core.whitespace=blank-at-eol,blank-at-eof,space-before-tab",
                                           "-c", "core.attributesfile=" + os.devnull,
                                           "diff", "--no-index", "--check", "--", os.devnull, str(path)],
                                          cwd=root, env=env, capture_output=True, check=False, timeout=5)
                    self.assertNotEqual(proc.returncode, 128, proc.stderr.decode())
                    result = weekly_ops._inspect_text_file(str(path))
                    if proc.stdout or proc.stderr:
                        self.assertFalse(result["ok"], proc.stdout.decode() + proc.stderr.decode())
                    elif data.endswith(b"\n") and b"\r" not in data:
                        self.assertTrue(result["ok"], result)


class PublicationParamsTests(unittest.TestCase):
    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory(prefix="startup 参数 ")
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.repo = self.root / "site"
        self.repo.mkdir()
        self.config = self.repo / "_config.yml"
        self.config.write_text('---\nurl: "https://example.test"\nbaseurl: ""\ntimezone: Asia/Shanghai\n'
                               'permalink: /:year/:month/:day/:title.html\n'
                               'defaults:\n  - scope: {path: "", type: posts}\n    values: {layout: single, author: Test}\n', encoding="utf-8")
        self.basename = "2026-09-16-embodied-ai-opportunity-radar.md"
        self.post = self.repo / "_posts" / self.basename
        self.overlay = "/assets/images/posts/2026-09-16-embodied-ai-weekly-header.png"
        self.metadata = self.root / "candidate.md"
        self.metadata.write_text('---\nlayout: single\ntitle: "具身产业链周报"\ndate: 2026-09-16 12:00:00 +0800\n'
                                 'categories: [AI]\nheader:\n  overlay_image: ' + self.overlay + '\n---\n', encoding="utf-8")
        self.page = self.repo / "weekly/embodied/index.html"
        self.page.parent.mkdir(parents=True)
        self.page.write_text('---\nlayout: list\nlist_kind: weekly\nbucket: embodied\npermalink: /weekly/embodied/\n---\n', encoding="utf-8")
        self.addCleanup(mock.patch.stopall)
        mock.patch.object(weekly_ops.subprocess, "run", side_effect=AssertionError("no subprocess in params check")).start()
        mock.patch.object(weekly_ops.subprocess, "Popen", side_effect=AssertionError("no executor in params check")).start()
        mock.patch("os.system", side_effect=AssertionError("no shell in params check")).start()
        mock.patch("socket.socket", side_effect=AssertionError("no network in params check")).start()

    def argv(self, **changes) -> list[str]:
        values = {"blog-repo": str(self.repo), "blog": "_posts/" + self.basename,
                  "front-matter": str(self.metadata), "expected-basename": self.basename,
                  "header-path": self.overlay,
                  "article-url": "https://example.test/2026/09/16/embodied-ai-opportunity-radar.html",
                  "image-url": "https://example.test" + self.overlay, "category": "AI"}
        values.update(changes)
        return ["check-publication-params"] + [part for key, value in values.items() if value is not None for part in ("--" + key, value)]

    def check(self, expected=1, reason="", **changes) -> dict:
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = weekly_ops.main(self.argv(**changes))
        result = json.loads(output.getvalue())
        self.assertEqual(code, expected, result)
        self.assertEqual(result["status"], "PUBLICATION_PARAMS_OK" if expected == 0 else "PUBLICATION_PARAMS_BLOCKED")
        self.assertTrue(result["read_only"])
        self.assertFalse(result["semantic_review_performed"])
        self.assertFalse(result["publication_verified"])
        self.assertEqual(result["schema_version"], 1)
        if reason:
            self.assertIn(reason, " ".join(result["failures"]))
        return result

    def replace(self, path: Path, old: str, new: str) -> None:
        text = path.read_text(encoding="utf-8")
        self.assertIn(old, text)
        path.write_text(text.replace(old, new), encoding="utf-8")

    def test_startup_without_post_or_image_read_only_and_repeatable(self) -> None:
        def snapshot():
            return {str(p): (p.read_bytes(), p.stat().st_mtime_ns, p.stat().st_mode)
                    for p in self.root.rglob("*") if p.is_file()}
        before = snapshot()
        result = self.check(0)
        self.assertEqual(result, self.check(0))
        self.assertEqual(snapshot(), before)
        self.assertEqual(result["resolved"]["input_mode"], "planned")
        self.assertFalse(self.post.exists())
        self.assertEqual(result["files"][str(self.config)]["sha256"], hashlib.sha256(self.config.read_bytes()).hexdigest())

    def test_existing_front_matter_must_equal_candidate(self) -> None:
        self.post.parent.mkdir()
        self.post.write_bytes(self.metadata.read_bytes() + b"Article body\n")
        self.assertEqual(self.check(0)["resolved"]["input_mode"], "existing")
        self.replace(self.post, "categories: [AI]", "categories: [News]")
        self.check(reason="differs from supplied candidate")

    def test_wrong_category_prefix_url_rejected_for_ai_and_news(self) -> None:
        for category in ("AI", "News"):
            with self.subTest(category=category):
                self.replace(self.metadata, "categories: [AI]", "categories: [" + category + "]")
                self.check(reason="article-url mismatch", **{"category": category, "article-url": "https://example.test/" + category.lower() + "/2026/09/16/embodied-ai-opportunity-radar.html"})
                self.check(0, **{"category": category})
                self.replace(self.metadata, "categories: [" + category + "]", "categories: [AI]")

    def test_multiple_categories_and_supported_date_forms(self) -> None:
        self.replace(self.metadata, "categories: [AI]", "categories: [AI, Agent]")
        original = self.metadata.read_text()
        for stamp in ("2026-09-16", "2026-09-16T12:00:00+08:00", '"2026-09-16 12:00:00 +0800"'):
            with self.subTest(stamp=stamp):
                self.metadata.write_text(original.replace("2026-09-16 12:00:00 +0800", stamp), encoding="utf-8")
                output = io.StringIO()
                with contextlib.redirect_stdout(output):
                    code = weekly_ops.main(self.argv() + ["--category", "Agent"])
                self.assertEqual(code, 0, output.getvalue())
                self.assertEqual(json.loads(output.getvalue())["resolved"]["categories"], ["AI", "Agent"])

    def test_actual_config_changes_are_not_cached_or_ignored(self) -> None:
        first = self.check(0)
        self.replace(self.config, "example.test", "changed.test")
        self.check(reason="article-url mismatch")
        result = self.check(0, **{"article-url": "https://changed.test/2026/09/16/embodied-ai-opportunity-radar.html",
                                 "image-url": "https://changed.test" + self.overlay})
        self.assertNotEqual(first["files"], result["files"])

    def test_nonempty_baseurl_and_static_post_permalink(self) -> None:
        self.replace(self.config, 'baseurl: ""', 'baseurl: "/blog"')
        self.replace(self.metadata, "layout: single\n", "layout: single\npermalink: /weekly/this-week/\n")
        result = self.check(0, **{"article-url": "https://example.test/blog/weekly/this-week/",
                                 "image-url": "https://example.test/blog" + self.overlay})
        self.assertEqual(result["resolved"]["rendered_relative_path"], "weekly/this-week/index.html")
        self.assertEqual(result["resolved"]["route_source"], "post-static-permalink")
        self.check(reason="article-url mismatch")

    def test_unsupported_site_permalink_fails_closed(self) -> None:
        original = self.config.read_text()
        for value in ("/:categories/:year/:month/:day/:title.html", "pretty", "/:slug/", "/:year/:title.html"):
            with self.subTest(value=value):
                self.config.write_text(original.replace("/:year/:month/:day/:title.html", value), encoding="utf-8")
                self.check(reason="unsupported permalink")

    def test_actual_config_required_and_routing_defaults_rejected(self) -> None:
        original = self.config.read_bytes()
        self.config.unlink()
        self.check(reason="_config.yml")
        self.config.write_bytes(original)
        for field in ("permalink: /other/", "date: 2026-09-15", "bucket: embodied", "header: {}", "published: false"):
            with self.subTest(field=field):
                # The existing defaults use flow style; replace them for a valid block mapping.
                self.config.write_text(original.decode().replace("    values: {layout: single, author: Test}", "    values:\n      layout: single\n      " + field), encoding="utf-8")
                self.check(reason="metadata defaults unsupported")

    def test_bad_site_origin_baseurl_timezone_and_custom_source(self) -> None:
        original = self.config.read_text()
        for old, new, reason in [('https://example.test', 'https://user:secret@example.test', "HTTP(S) origin"),
                                 ('https://example.test', 'https://example.test/path', "HTTP(S) origin"),
                                 ('https://example.test', 'https://example.test?', "noncanonical origin"),
                                 ('https://example.test', 'https://example.test#', "noncanonical origin"),
                                 ('https://example.test', 'https://example.test:99999', "Port out of range"),
                                 ('baseurl: ""', 'baseurl: "/a/../b"', "traversal"),
                                 ('baseurl: ""', 'baseurl: "/blog/"', "trailing slash"),
                                 ('timezone: Asia/Shanghai', 'timezone: UTC', "timezone"),
                                 ('timezone: Asia/Shanghai', 'timezone: Asia/Shanghai\nsource: other', "custom source")]:
            with self.subTest(new=new):
                self.config.write_text(original.replace(old, new), encoding="utf-8")
                self.check(reason=reason)

    def test_expected_basename_not_inferred_from_display_title(self) -> None:
        self.check(0)
        self.check(reason="basename differs", **{"expected-basename": "2026-09-16-embodied-ai-industry-weekly.md"})
        self.check(reason="directly within _posts", **{"blog": "_posts/AI/" + self.basename})
        for name in ("2026-02-30-test.md", "2026-09-16-UPPER.md", "2026-09-16-test.md.bak", "2026-09-16-中文.md"):
            with self.subTest(name=name):
                self.check(**{"blog": "_posts/" + name, "expected-basename": name})

    def test_wrong_header_directory_date_extension_or_declared_path(self) -> None:
        original = self.metadata.read_text()
        for overlay in (self.overlay.replace("/posts/", "/"), self.overlay.replace("09-16", "09-15"),
                        self.overlay.replace(".png", ".svg"), "/assets/images/posts/../escape.png",
                        self.overlay + "?v=1", self.overlay.replace("posts", "%70osts")):
            with self.subTest(overlay=overlay):
                self.metadata.write_text(original.replace(self.overlay, overlay), encoding="utf-8")
                self.check(**{"header-path": overlay, "image-url": "https://example.test" + overlay})
        self.metadata.write_text(original, encoding="utf-8")
        self.check(reason="differs from --header-path", **{"header-path": self.overlay.replace("header", "different")})
        self.check(reason="image-url mismatch", **{"image-url": "https://example.test/assets/images/wrong.png"})

    def test_categories_layout_title_date_and_published_metadata(self) -> None:
        original = self.metadata.read_text()
        cases = [("categories: [AI]", "categories: [News]", "categories"),
                 ("categories: [AI]", "categories: AI", "categories"),
                 ("layout: single", "layout: page", "layout"),
                 ('title: "具身产业链周报"', 'title: ""', "title"),
                 ("2026-09-16 12:00:00 +0800", "2026-09-15 12:00:00 +0800", "date"),
                 ("2026-09-16 12:00:00 +0800", "2026-09-16 12:00:00 +0000", "date"),
                 ("2026-09-16 12:00:00 +0800", "2026-09-16 25:00:00 +0800", "hour"),
                 ("layout: single", "layout: single\npublished: false", "published"),
                 ("layout: single", "layout: single\nslug: changed", "overrides")]
        for old, new, reason in cases:
            with self.subTest(new=new):
                self.metadata.write_text(original.replace(old, new), encoding="utf-8")
                self.check(reason=reason)

    def test_explicit_embodied_bucket_requires_real_matching_page(self) -> None:
        self.replace(self.metadata, "layout: single", "layout: single\nbucket: embodied")
        result = self.check(0, bucket="embodied", **{"bucket-page": "weekly/embodied/index.html"})
        self.assertIn("bucket-column-metadata", result["checked"])
        self.check(reason="bucket differs")
        self.check(reason="requires --bucket-page", bucket="embodied")
        self.check(reason="bucket differs", bucket="weekly", **{"bucket-page": str(self.page)})
        self.replace(self.page, "bucket: embodied", "bucket: other")
        self.check(reason="matching published", bucket="embodied", **{"bucket-page": str(self.page)})
        self.page.unlink()
        self.check(reason="index.html", bucket="embodied", **{"bucket-page": str(self.page)})

    def test_bucket_page_cannot_be_index_all_article_or_private_metadata(self) -> None:
        self.replace(self.metadata, "layout: single", "layout: single\nbucket: embodied")
        original = self.page.read_text()
        for value in ("weekly_all", "article", "article_all"):
            with self.subTest(kind=value):
                self.page.write_text(original.replace("list_kind: weekly", "list_kind: " + value), encoding="utf-8")
                self.check(reason="matching published", bucket="embodied", **{"bucket-page": str(self.page)})
        private = self.repo / "_site/weekly/embodied/index.html"
        private.parent.mkdir(parents=True)
        private.write_text(original, encoding="utf-8")
        self.check(reason="public source page", bucket="embodied", **{"bucket-page": str(private)})
        self.check(reason="bucket differs", **{"bucket-page": str(self.page)})

    def test_bucket_page_without_bucket_is_rejected(self) -> None:
        self.check(reason="bucket-page requires", **{"bucket-page": str(self.page)})
        self.replace(self.metadata, "layout: single", "layout: single\nbucket: null")
        self.check(reason="bucket differs")

    def test_changed_bucket_name_not_silently_remapped_to_a_real_column(self) -> None:
        self.replace(self.metadata, "layout: single", "layout: single\nbucket: ai-industry")
        self.replace(self.page, "bucket: embodied", "bucket: industry")
        self.check(reason="matching published", bucket="ai-industry", **{"bucket-page": str(self.page)})

    def test_duplicate_yaml_keys_nested_keys_alias_tags_and_bad_yaml(self) -> None:
        original = self.metadata.read_text()
        cases = [original.replace("layout: single", "layout: single\nlayout: page"),
                 original.replace("  overlay_image:", "  overlay_image: /first.png\n  overlay_image:"),
                 original.replace("categories: [AI]", "categories: &c [AI]\nalias: *c"),
                 original.replace("categories: [AI]", "categories: !!python/object/apply:os.system ['false']"),
                 original.replace("categories: [AI]", "categories: [AI"),
                 "---\n- array\n---\n"]
        for text in cases:
            with self.subTest(text=text[:60]):
                self.metadata.write_text(text, encoding="utf-8")
                self.check()
        self.metadata.write_text(original, encoding="utf-8")
        self.config.write_text(self.config.read_text() + "url: https://evil.test\n", encoding="utf-8")
        self.check(reason="duplicate")

    def test_yaml_dependency_missing_is_blocked_not_legacy_dependency(self) -> None:
        with mock.patch.dict("sys.modules", {"yaml": None}):
            self.check(reason="requires installed PyYAML")
            self.assertTrue(weekly_ops._inspect_text_file(str(self.metadata))["ok"])

    def test_bom_crlf_invalid_utf8_and_yaml_size(self) -> None:
        original = self.metadata.read_bytes()
        excessive_tokens = "---\n" + "".join(f"key{i}: value\n" for i in range(3000)) + "---\n"
        self.assertLess(len(excessive_tokens.encode()), 128 * 1024)
        self.metadata.write_text(excessive_tokens, encoding="utf-8")
        self.check(reason="excessive tokens")
        for data, reason in [(b"\xef\xbb\xbf" + original, "byte-zero"),
                             (original.replace(b"\n", b"\r\n"), "byte-zero"), (b"\xff", "UTF-8"),
                             (b"---\ntitle: " + b"a" * (128 * 1024) + b"\n---\n", "128 KiB")]:
            with self.subTest(reason=reason):
                self.metadata.write_bytes(data)
                self.check(reason=reason)

    def test_symlink_escape_missing_fifo_and_parent_symlink_rejected(self) -> None:
        original = self.metadata.read_bytes()
        for kind in ("symlink", "fifo", "missing"):
            with self.subTest(kind=kind):
                self.metadata.unlink()
                if kind == "symlink":
                    self.metadata.symlink_to(self.config)
                elif kind == "fifo":
                    os.mkfifo(self.metadata)
                self.check()
                if self.metadata.exists() or self.metadata.is_symlink():
                    self.metadata.unlink()
                self.metadata.write_bytes(original)
        self.check(reason="outside", blog=str(self.root / self.basename))
        link = self.root / "site-link"
        link.symlink_to(self.repo, target_is_directory=True)
        self.check(reason="symlink", **{"blog-repo": str(link)})
        images = self.repo / "assets/images"
        images.mkdir(parents=True)
        (images / "posts").symlink_to(self.root, target_is_directory=True)
        self.check(reason="symlink")

    def test_config_bucket_page_and_existing_post_symlinks_are_rejected(self) -> None:
        self.post.parent.mkdir()
        self.post.symlink_to(self.metadata)
        self.check(reason="symlink")
        self.post.unlink()
        original = self.config.read_bytes()
        target = self.root / "real-config.yml"
        target.write_bytes(original)
        self.config.unlink()
        self.config.symlink_to(target)
        self.check(reason="symlink")
        self.config.unlink()
        self.config.write_bytes(original)
        self.replace(self.metadata, "layout: single", "layout: single\nbucket: embodied")
        page_target = self.root / "real-page.html"
        page_target.write_bytes(self.page.read_bytes())
        self.page.unlink()
        self.page.symlink_to(page_target)
        self.check(reason="symlink", bucket="embodied", **{"bucket-page": str(self.page)})
        self.check(reason="outside", bucket="embodied", **{"bucket-page": str(page_target)})

    def test_unsafe_post_permalinks_rejected(self) -> None:
        original = self.metadata.read_text()
        for value in ("/../../escape/", "//evil.test/x", "/%2e%2e/x/", "/:categories/:title/", "https://evil.test/", "/no-extension", "/x/?q=1"):
            with self.subTest(value=value):
                self.metadata.write_text(original.replace("layout: single", "layout: single\npermalink: " + value), encoding="utf-8")
                self.check()

    def test_input_mutation_detected_and_saved_json_cannot_attest(self) -> None:
        (self.root / "forged.json").write_text('{"status":"PUBLICATION_PARAMS_OK"}', encoding="utf-8")
        real_read = weekly_ops._read_stable_bytes
        changed = False
        def mutate(path):
            nonlocal changed
            data, normalized = real_read(path)
            if Path(path) == self.metadata and not changed:
                changed = True
                self.replace(self.config, "example.test", "changed.test")
            return data, normalized
        with mock.patch.object(weekly_ops, "_read_stable_bytes", side_effect=mutate):
            self.check(reason="input changed during parameter check")

    def test_help_and_required_parameters_use_real_cli(self) -> None:
        output = io.StringIO()
        with contextlib.redirect_stdout(output), self.assertRaises(SystemExit) as raised:
            weekly_ops.main(["check-publication-params", "--help"])
        self.assertEqual(raised.exception.code, 0)
        self.assertIn("--bucket-page", output.getvalue())
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as raised:
            weekly_ops.main(["check-publication-params", "--blog-repo", str(self.repo)])
        self.assertEqual(raised.exception.code, 2)


if __name__ == "__main__":
    unittest.main()
