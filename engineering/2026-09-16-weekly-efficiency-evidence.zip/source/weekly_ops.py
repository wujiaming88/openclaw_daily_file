#!/usr/bin/env python3
"""Deterministic helpers for weekly-report cron jobs."""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
import re
import stat
import subprocess
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit

NL = chr(10)
MAX_TEXT_BYTES = 64 * 1024 * 1024
MAX_TEXT_ISSUES = 200


def insert_index(args: argparse.Namespace) -> int:
    repo = Path(args.repo).expanduser().resolve()
    index = repo / "INDEX.md"
    if not index.exists():
        raise SystemExit(f"INDEX.md not found: {index}")

    rel_file = args.file.strip().lstrip("/")
    row = f"| [{args.title}]({rel_file}) | {args.dir} | {args.author} | {args.summary} |"
    text = index.read_text(encoding="utf-8")

    # Compare whole inline-link destinations; a .md.bak link is a different file.
    targets = re.findall(r"\[[^\]\n]*\]\(([^)\n]*)\)", text)
    if rel_file in targets:
        print(f"index already contains {rel_file}")
        return 0

    date_heading = f"## {args.date}"
    if date_heading in text:
        start = text.index(date_heading)
        next_heading = text.find(NL + "## ", start + len(date_heading))
        section_end = len(text) if next_heading == -1 else next_heading + 1
        section = text[start:section_end]
        sep = "|------|------|--------|------|"
        sep_pos_rel = section.find(sep)
        if sep_pos_rel == -1:
            raise SystemExit(f"table separator not found in section {date_heading}")
        insert_at = start + sep_pos_rel + len(sep)
        text = text[:insert_at] + NL + row + text[insert_at:]
    else:
        new_section = NL.join([
            f"## {args.date}",
            "",
            "| 文件 | 目录 | 产出人 | 说明 |",
            "|------|------|--------|------|",
            row,
            "",
            "---",
            "",
        ])
        top_marker = "---" + NL + NL
        top_pos = text.find(top_marker)
        if top_pos != -1:
            insert_at = top_pos + len(top_marker)
            text = text[:insert_at] + new_section + text[insert_at:]
        else:
            first_heading = text.find(NL + "## ")
            if first_heading != -1:
                insert_at = first_heading + 1
                text = text[:insert_at] + new_section + text[insert_at:]
            else:
                if not text.endswith(NL):
                    text += NL
                text += NL + new_section

    index.write_text(text, encoding="utf-8")
    print(f"inserted {rel_file} into INDEX.md under {args.date}")
    return 0


def _strip_md(line: str) -> str:
    line = line.strip()
    for ch in "#>*-` ":
        line = line.strip(ch + " ")
    return " ".join(line.split())


def insert_index_auto(args: argparse.Namespace) -> int:
    repo = Path(args.repo).expanduser().resolve()
    rel_file = args.file.strip().lstrip("/")
    report = repo / rel_file
    if not report.exists():
        raise SystemExit(f"report file not found: {report}")

    date = args.date or report.name[:10]
    if len(date) != 10 or date[4] != "-" or date[7] != "-":
        raise SystemExit(f"cannot derive date from file name; pass --date explicitly: {report.name}")

    lines = report.read_text(encoding="utf-8").splitlines()
    title = args.title
    if not title:
        for line in lines[:80]:
            if line.startswith("# "):
                title = _strip_md(line)
                break
    if not title:
        title = report.stem

    summary = args.summary
    if not summary:
        candidates: list[str] = []
        capture_after = False
        for line in lines[:180]:
            t = _strip_md(line)
            if not t:
                continue
            if line.startswith("# "):
                continue
            if "本周一句话" in t:
                capture_after = True
                continue
            if capture_after or "四维" in t or "覆盖" in t or "TOP" in t or "本周" in t:
                candidates.append(t)
            if len(candidates) >= 4:
                break
        if not candidates:
            for line in lines[:120]:
                t = _strip_md(line)
                if t and not line.startswith("# ") and not t.startswith("layout:"):
                    candidates.append(t)
                if len(candidates) >= 3:
                    break
        summary = " ".join(candidates)
        if len(summary) > 420:
            summary = summary[:417].rstrip() + "…"
        if not summary:
            summary = f"{title}，详见报告全文。"

    ns = argparse.Namespace(
        repo=str(repo),
        date=date,
        file=rel_file,
        dir=args.dir,
        author=args.author,
        title=title,
        summary=summary,
    )
    return insert_index(ns)


def _failures_add(failures: list[str], condition: bool, message: str) -> None:
    if not condition:
        failures.append(message)


def _count_rendered_tables(markdown_path: Path) -> tuple[int, int, int] | None:
    """Return (source_tables, rendered_tables, pre_blocks) when kramdown is available."""
    source = markdown_path.read_text(encoding="utf-8")
    source_tables = sum(
        1
        for line in source.splitlines()
        if re.match(r"^\|\s*:?-{3,}:?\s*\|", line)
    )
    if source_tables == 0:
        return (0, 0, 0)

    # Strip front matter for kramdown, matching the manual check in weekly prompts.
    lines = source.splitlines()
    body_lines = lines
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                body_lines = lines[i + 1 :]
                break
    body = NL.join(body_lines)
    try:
        proc = subprocess.run(
            ["kramdown", "--input", "GFM"],
            input=body,
            text=True,
            capture_output=True,
            check=False,
            timeout=30,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    html = proc.stdout
    return (source_tables, html.count("<table>"), html.count("<pre>"))


def _front_matter(text: str) -> str | None:
    """Return YAML front matter only when it starts at byte zero."""
    if text.startswith("\ufeff") or not text.startswith("---\n"):
        return None
    end = text.find("\n---\n", 4)
    if end == -1:
        return None
    return text[4:end]


def _overlay_path(front_matter: str) -> str | None:
    match = re.search(r'^\s*overlay_image:\s*["\']?([^"\'\s#]+)', front_matter, re.M)
    return match.group(1) if match else None


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _duplicate_post_images(repo: Path, image: Path) -> list[Path]:
    """Return other post images whose bytes are identical to image."""
    image_hash = _sha256(image)
    image_root = repo / "assets" / "images" / "posts"
    duplicates: list[Path] = []
    for candidate in image_root.iterdir():
        if candidate == image or not candidate.is_file():
            continue
        if candidate.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
            continue
        if candidate.stat().st_size != image.stat().st_size:
            continue
        if _sha256(candidate) == image_hash:
            duplicates.append(candidate)
    return sorted(duplicates)


class _VisibleHTMLText(HTMLParser):
    """Extract body text, preserving inline joins and block/BR line boundaries.

    This is static HTML inspection, not CSS/JS rendering or a freshness check.
    """
    _invisible = {"head", "script", "style", "template"}
    _void = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}
    _blocks = {"address", "article", "aside", "blockquote", "br", "dd", "div", "dl", "dt", "footer", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hr", "li", "main", "nav", "ol", "p", "pre", "section", "table", "tr", "ul"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.hidden: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if self.hidden or tag in self._invisible or any(key == "hidden" for key, _ in attrs):
            if tag not in self._void:
                self.hidden.append(tag)
        elif tag in self._blocks:
            self.parts.append(NL)

    def handle_endtag(self, tag: str) -> None:
        if self.hidden:
            if tag in self.hidden:
                del self.hidden[len(self.hidden) - 1 - self.hidden[::-1].index(tag):]
        elif tag in self._blocks:
            self.parts.append(NL)

    def handle_data(self, data: str) -> None:
        if not self.hidden:
            self.parts.append(data)


def _has_visible_front_matter(html: str) -> bool:
    parser = _VisibleHTMLText()
    parser.feed(html)
    parser.close()
    # Match a metadata line, not prose explaining the layout syntax. Do not
    # broaden the existing single-layout sentinel to arbitrary YAML/content.
    return any(" ".join(line.split()) == "layout: single"
               for line in "".join(parser.parts).splitlines())


def _rendered_blog_path(site: Path, blog: Path, front_matter: str | None, failures: list[str]) -> Path:
    """Resolve the same Jekyll output path for both local validators."""
    match = re.search(r"^permalink:\s*(\S+)", front_matter, re.M) if front_matter is not None else None
    permalink = match.group(1).strip('\"\'') if match else None
    if permalink:
        rendered = site / permalink.lstrip("/")
        return rendered / "index.html" if permalink.endswith("/") else rendered
    match = re.match(r"(\d{4})-(\d{2})-(\d{2})-(.+)\.md$", blog.name)
    _failures_add(failures, match is not None, f"blog: filename must be YYYY-MM-DD-slug.md: {blog.name}")
    if match is None:
        return site / "__invalid_post_name__"
    year, month, day, slug = match.groups()
    return site / year / month / day / f"{slug}.html"


def validate_blog_post(args: argparse.Namespace) -> int:
    """Generic mechanical preflight for one Jekyll post and its header image."""
    repo = Path(args.repo).expanduser().resolve()
    blog_arg = Path(args.blog).expanduser()
    blog = blog_arg.resolve() if blog_arg.is_absolute() else (repo / blog_arg).resolve()
    failures: list[str] = []

    _failures_add(failures, blog.is_file(), f"blog not found: {blog}")
    if failures:
        for item in failures:
            print(f"FAIL: {item}")
        return 1

    raw = blog.read_bytes()
    text = raw.decode("utf-8", errors="replace")
    front_matter = _front_matter(text)
    _failures_add(
        failures,
        raw.startswith(b"---\n"),
        "blog: byte zero must be '-' from opening '---' (no BOM, blank line, or whitespace before front matter)",
    )
    _failures_add(failures, front_matter is not None, "blog: valid closing front matter delimiter missing")

    overlay = _overlay_path(front_matter) if front_matter is not None else None
    _failures_add(failures, overlay is not None, "blog: header.overlay_image missing from front matter")
    image = None
    if overlay is not None:
        _failures_add(failures, overlay.startswith("/assets/images/posts/"), f"blog: unexpected overlay_image path: {overlay}")
        _failures_add(
            failures,
            text.count(overlay) == 1,
            f"blog: overlay image path must appear exactly once in source, found {text.count(overlay)}",
        )
        image = repo / overlay.lstrip("/")
        _failures_add(failures, image.is_file(), f"blog: overlay image file missing: {image}")
        if image.is_file():
            _failures_add(failures, image.stat().st_size > 0, f"blog: overlay image is empty: {image}")
            post_match = re.match(r"(\d{4}-\d{2}-\d{2})-.+\.md$", blog.name)
            if post_match is not None:
                post_date = post_match.group(1)
                _failures_add(
                    failures,
                    image.name.startswith(post_date + "-"),
                    f"blog: overlay image filename must start with post date {post_date}: {image.name}",
                )
            duplicates = _duplicate_post_images(repo, image)
            _failures_add(
                failures,
                not duplicates,
                "blog: overlay image duplicates existing post image bytes (SHA-256): "
                + ", ".join(str(path) for path in duplicates),
            )

    _failures_add(failures, "TODO" not in text and "待补" not in text, "blog: TODO-like placeholder remains")
    _failures_add(failures, re.search(r"^[ \t]+\|", text, re.M) is None, "blog: indented table row found")

    rendered = _count_rendered_tables(blog)
    if rendered is not None:
        source_tables, rendered_tables, pre_blocks = rendered
        _failures_add(
            failures,
            source_tables == rendered_tables,
            f"blog: table render mismatch source={source_tables} rendered={rendered_tables}",
        )
        _failures_add(failures, pre_blocks == 0, f"blog: unexpected pre/code blocks rendered={pre_blocks}")

    if args.site:
        site = Path(args.site).expanduser().resolve()
        rendered_file = _rendered_blog_path(site, blog, front_matter, failures)

        _failures_add(failures, rendered_file.is_file(), f"blog: rendered HTML missing after Jekyll build: {rendered_file}")
        if rendered_file.is_file():
            html = rendered_file.read_text(encoding="utf-8", errors="replace")
            _failures_add(failures, not _has_visible_front_matter(html), "blog: raw front matter leaked into rendered HTML")
            if overlay is not None:
                _failures_add(failures, overlay in html, f"blog: rendered HTML does not reference overlay image: {overlay}")
            source_tables = _count_rendered_tables(blog)
            if source_tables is not None:
                expected_tables = source_tables[0]
                _failures_add(
                    failures,
                    html.count("<table") == expected_tables,
                    f"blog: built table mismatch source={expected_tables} built={html.count('<table')}",
                )

    if failures:
        print("validate-blog-post: FAIL")
        for item in failures:
            print(f"FAIL: {item}")
        return 1

    print("validate-blog-post: OK")
    print(f"blog={blog}")
    if image is not None:
        print(f"image={image}")
    if args.site:
        print(f"rendered={rendered_file}")
    return 0


def validate_startup_weekly(args: argparse.Namespace) -> int:
    """Deterministic preflight for the startup weekly report/blog pair."""
    report = Path(args.report).expanduser().resolve()
    blog = Path(args.blog).expanduser().resolve()
    image = Path(args.image).expanduser().resolve() if args.image else None
    failures: list[str] = []

    _failures_add(failures, report.exists(), f"report not found: {report}")
    _failures_add(failures, blog.exists(), f"blog not found: {blog}")
    if image is not None:
        _failures_add(failures, image.exists(), f"image not found: {image}")
    if failures:
        for item in failures:
            print(f"FAIL: {item}")
        return 1

    report_text = report.read_text(encoding="utf-8")
    blog_text = blog.read_text(encoding="utf-8")
    report_date = report.name[:10]

    for label, text in (("report", report_text), ("blog", blog_text)):
        _failures_add(failures, f"第 " in text and " 期" in text, f"{label}: issue number missing")
        _failures_add(failures, "第 N" not in text and "第 X" not in text, f"{label}: placeholder issue number remains")
        _failures_add(failures, report_date in text or label == "report", f"{label}: report date {report_date} not visible")
        _failures_add(failures, "TODO" not in text and "待补" not in text, f"{label}: TODO-like placeholder remains")
        _failures_add(failures, "\\n" not in text, f"{label}: literal \\n remains")
        for bad in ("Repeat. 团队上", "Dr. 竞争力上", "€17.\n", "$20M（约 €17.\n"):
            _failures_add(failures, bad not in text, f"{label}: known truncation fragment remains: {bad!r}")

    _failures_add(failures, "layout: single" in blog_text, "blog: layout: single missing")
    _failures_add(failures, re.search(r"^date: .*\+0800", blog_text, re.M) is not None, "blog: date missing +0800 timezone")
    _failures_add(failures, "overlay_image:" in blog_text, "blog: overlay_image missing")
    _failures_add(failures, "header" in blog_text[:800], "blog: header front matter missing")

    bare_url_re = re.compile(r"(^|[^\(])https?://[^\s\)）\]；;，,。<>]+", re.M)
    _failures_add(failures, bare_url_re.search(blog_text) is None, "blog: bare URL found; use markdown links")
    for internal in ("openclaw_daily_file", "shared/artifacts", "黄山", "小帅", "A组", "B组", "C组", "D组"):
        _failures_add(failures, internal not in blog_text, f"blog: internal marker leaked: {internal}")

    # Required startup-weekly substance markers.
    for marker in ("本周 TOP 5", "分地域详情", "本周创业市场观察", "产品深研", "融资记录", "创始人", "竞争力", "赛道分析", "原文链接", "投资/合作视角"):
        _failures_add(failures, marker in report_text or marker in blog_text, f"content marker missing: {marker}")

    # Kramdown compatibility: indented table rows are always suspicious; rendered table count must match when available.
    indented_table = re.search(r"^[ \t]+\|", blog_text, re.M)
    _failures_add(failures, indented_table is None, "blog: indented table row found")
    rendered = _count_rendered_tables(blog)
    if rendered is not None:
        source_tables, rendered_tables, pre_blocks = rendered
        _failures_add(
            failures,
            source_tables == rendered_tables,
            f"blog: table render mismatch source={source_tables} rendered={rendered_tables}",
        )
        _failures_add(failures, pre_blocks == 0, f"blog: unexpected pre/code blocks rendered={pre_blocks}")

    if failures:
        print("validate-startup-weekly: FAIL")
        for item in failures:
            print(f"FAIL: {item}")
        return 1

    print("validate-startup-weekly: OK")
    print(f"report={report}")
    print(f"blog={blog}")
    if image is not None:
        print(f"image={image}")
    return 0


def _publication_path(raw: str, label: str, root: Path | None = None) -> Path:
    path = Path(raw).expanduser()
    if not path.is_absolute():
        if root is None:
            raise ValueError(f"{label}: absolute path required")
        path = root / path
    if any(part.is_symlink() for part in (path, *path.parents)):
        raise ValueError(f"{label}: symlink not allowed")
    resolved = path.resolve()
    if root is not None and not resolved.is_relative_to(root):
        raise ValueError(f"{label}: outside repository/build root")
    return resolved


def _check_done(text: str, label: str, expected: dict[str, str]) -> None:
    """Strict flat handoff fields, not YAML, audit prose, or signed attestations."""
    if re.search(r"\bBLOCKED\b", text):
        raise ValueError(f"{label}: BLOCKED marker remains")
    for key, value in expected.items():
        values = re.findall(rf"^{key}:[ \t]*([^\r\n]*)\r?$", text, re.M)
        if values != [value]:
            raise ValueError(f"{label}: require exactly one matching {key}")


def _has_index_entry(text: str, date: str, target: str) -> bool:
    # Do not accept a plain mention, comment, code sample, or another date.
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    in_date = False
    fence = None
    for line in text.splitlines():
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})", line)
        if marker:
            token = marker.group(1)
            if fence is None:
                fence = token
            elif token[0] == fence[0] and len(token) >= len(fence):
                fence = None
            continue
        if fence is not None:
            continue
        if re.match(r"^#{1,2} ", line):
            in_date = line.strip() == f"## {date}"
        if in_date and line.startswith("|") and line.rstrip().endswith("|"):
            if target in re.findall(r"\[[^\]\n]*\]\(([^)\n]*)\)", line):
                return True
    return False


def _open_absolute_regular(path_text: str) -> tuple[int, Path]:
    """Open an absolute regular file without following any path symlink."""
    path = Path(path_text).expanduser()
    if not path.is_absolute():
        raise ValueError("absolute path required")
    parts = path.parts
    directory_fd = os.open(parts[0], os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        for component in parts[1:-1]:
            next_fd = os.open(
                component,
                os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                dir_fd=directory_fd,
            )
            os.close(directory_fd)
            directory_fd = next_fd
        fd = os.open(
            parts[-1],
            os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC,
            dir_fd=directory_fd,
        )
    finally:
        os.close(directory_fd)
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode):
        os.close(fd)
        raise ValueError("regular file required (symlink, directory, FIFO and device are rejected)")
    return fd, path


def _eof_issue(data: bytes) -> tuple[str, int] | None:
    if not data.endswith(b"\n"):
        return ("EOF must end with exactly one LF", len(data))
    if data.endswith(b"\r\n"):
        return ("EOF must use LF, not CRLF", len(data) - 2)
    prior_line_start = data.rfind(b"\n", 0, len(data) - 1) + 1
    if data[prior_line_start:-1].strip(b" \t\r") == b"":
        return ("EOF has an extra trailing blank or whitespace-only line", prior_line_start)
    return None


def _text_location(data: bytes, offset: int) -> dict[str, int]:
    bounded = max(0, min(offset, len(data)))
    line = data.count(b"\n", 0, bounded) + 1
    last_lf = data.rfind(b"\n", 0, bounded)
    return {"byte_offset": bounded, "line": line, "column": bounded - last_lf}


def _whitespace_issues(data: bytes):
    """Scan every LF-delimited line, independent of Git tracking/diff state.

    Match Git's default blank-at-eol/blank-at-eof/space-before-tab rules,
    plus our stricter LF-only text contract. Columns are byte columns.
    This deliberately does not interpret or modify Markdown/code whitespace.
    """
    offset = 0
    blank_start = None
    for number, physical in enumerate(io.BytesIO(data), 1):
        raw = physical[:-1] if physical.endswith(b"\n") else physical
        line = raw[:-1] if raw.endswith(b"\r") else raw

        def issue(code: str, message: str, column: int) -> dict[str, object]:
            return {"code": code, "message": message, "line": number,
                    "column": column + 1, "byte_offset": offset + column}

        for match in re.finditer(b"\r", raw):
            yield issue("crlf" if match.start() == len(raw) - 1 and offset + len(raw) < len(data)
                        else "carriage-return", "LF-only text required; CR must be reviewed, not silently normalized",
                        match.start())
        trailing = re.search(rb"[ \t]+$", line)
        if trailing:
            item = issue("blank-at-eol", "trailing whitespace (Git blank-at-eol)", trailing.start())
            item["hint"] = ("If these spaces encode a Markdown hard break, the sole writer may manually "
                            "rewrite it (for example as <br>) after checking rendering and meaning; "
                            "never blanket-rstrip or trim code whitespace.")
            yield item
        indent = re.match(rb"[ \t]*", line).group()
        for match in re.finditer(rb" +\t", indent):
            yield issue("space-before-tab", "space before tab in indentation (Git space-before-tab)", match.start())
        if not line.strip(b" \t\r"):
            if blank_start is None:
                blank_start = (number, offset)
        else:
            blank_start = None
        offset += len(raw) + 1
    if blank_start is not None:
        number, offset = blank_start
        yield {"code": "blank-at-eof", "message": "trailing blank line(s) (Git blank-at-eof)",
               "line": number, "column": 1, "byte_offset": offset}


def _read_stable_bytes(path_text: str) -> tuple[bytes, Path]:
    """Bounded no-follow regular-file read shared by read-only entry points."""
    fd, normalized = _open_absolute_regular(path_text)
    try:
        before = os.fstat(fd)
        chunks: list[bytes] = []
        total = 0
        while True:
            chunk = os.read(fd, min(1024 * 1024, MAX_TEXT_BYTES + 1 - total))
            if not chunk:
                break
            chunks.append(chunk)
            total += len(chunk)
            if total > MAX_TEXT_BYTES:
                raise ValueError(f"file exceeds bounded read limit of {MAX_TEXT_BYTES} bytes")
        data = b"".join(chunks)
        after = os.fstat(fd)
        stable_fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
        if any(getattr(before, key) != getattr(after, key) for key in stable_fields) or after.st_size != len(data):
            raise ValueError("file changed during read")
        return data, normalized
    finally:
        os.close(fd)


def _inspect_text_file(path_text: str) -> dict[str, object]:
    result: dict[str, object] = {
        "path": path_text, "ok": False, "sha256": None, "bytes": None, "lines": None, "issues": []
    }
    issues = result["issues"]
    assert isinstance(issues, list)
    data = b""
    try:
        data, normalized = _read_stable_bytes(path_text)
        result["path"] = str(normalized)
        result.update({
            "sha256": hashlib.sha256(data).hexdigest(),
            "bytes": len(data),
            "lines": data.count(b"\n") + (0 if data.endswith(b"\n") else 1),
        })
        if not data:
            issues.append({"code": "empty", "message": "nonempty UTF-8 text required", **_text_location(data, 0)})
        try:
            text = data.decode("utf-8")
            if not text.strip():
                issues.append({"code": "blank", "message": "text must contain non-whitespace content", **_text_location(data, 0)})
        except UnicodeDecodeError as exc:
            issues.append({"code": "utf8", "message": "valid UTF-8 required", **_text_location(data, exc.start)})
        eof = _eof_issue(data) if data else None
        if eof is not None:
            message, offset = eof
            issues.append({"code": "eof", "message": message, **_text_location(data, offset)})
        count = len(issues)
        for item in _whitespace_issues(data):
            count += 1
            if len(issues) < MAX_TEXT_ISSUES:
                issues.append(item)
        result["issue_count"] = count
    except (OSError, ValueError) as exc:
        issues.append({"code": "unsafe-input", "message": str(exc)})
    result.setdefault("issue_count", len(issues))
    result["issues_truncated"] = result["issue_count"] > len(issues)
    result["ok"] = not issues
    return result


def check_inputs(args: argparse.Namespace) -> int:
    """Read-only, bounded, aggregate validation of candidate frozen texts."""
    files = [_inspect_text_file(item) for item in args.file]
    ok = all(bool(item["ok"]) for item in files)
    print(json.dumps({
        "status": "CHECK_INPUTS_PASS" if ok else "CHECK_INPUTS_BLOCKED",
        "ok": ok,
        "read_only": True,
        "semantic_review_performed": False,
        "whitespace_policy": ["blank-at-eol", "blank-at-eof", "space-before-tab", "LF-only"],
        "git_check_performed": False,
        "limits": {"max_bytes_per_file": MAX_TEXT_BYTES, "max_issues_per_file": MAX_TEXT_ISSUES},
        "files": files,
    }, ensure_ascii=False, sort_keys=True))
    return 0 if ok else 1

def _yaml_mapping(text: str, label: str) -> dict:
    """Small safe YAML boundary; reject duplicate keys/aliases instead of guessing.

    PyYAML is optional for legacy commands; only the new parameter check uses it.
    No unsafe YAML constructors, Liquid, Ruby, plugins or external programs are executed.
    """
    try:
        import yaml
    except ImportError as exc:
        raise ValueError("check-publication-params requires installed PyYAML; no fallback parser") from exc
    if len(text.encode("utf-8")) > 128 * 1024:
        raise ValueError(f"{label}: YAML exceeds 128 KiB limit")

    class UniqueLoader(yaml.SafeLoader):
        def construct_mapping(self, node, deep=False):
            mapping = {}
            for key_node, value_node in node.value:
                key = self.construct_object(key_node, deep=deep)
                if not isinstance(key, str) or key in mapping or key == "<<":
                    raise ValueError(f"{label}: duplicate/non-string/merge key at line {key_node.start_mark.line + 1}")
                mapping[key] = self.construct_object(value_node, deep=deep)
            return mapping

    try:
        for index, token in enumerate(yaml.scan(text)):
            if index >= 8192 or isinstance(token, (yaml.tokens.AliasToken, yaml.tokens.AnchorToken, yaml.tokens.TagToken)):
                raise ValueError(f"{label}: YAML aliases, anchors, explicit tags or excessive tokens are unsupported")
        value = yaml.load(text, Loader=UniqueLoader)
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        location = f" at line {mark.line + 1}" if mark is not None else ""
        raise ValueError(f"{label}: invalid or unsupported YAML{location}") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{label}: YAML mapping required")
    return value


def _url_path(value: object, label: str, *, directory: bool = False) -> str:
    """Canonical ASCII URL path subset: no escapes, traversal, query or fragment."""
    if not isinstance(value, str) or not re.fullmatch(r"/[A-Za-z0-9_./-]+", value):
        raise ValueError(f"{label}: canonical root-relative URL path required")
    parts = value[1:].rstrip("/").split("/")
    if any(part in ("", ".", "..") for part in parts) or "//" in value:
        raise ValueError(f"{label}: empty or traversal path component")
    if directory and value.endswith("/"):
        raise ValueError(f"{label}: omit trailing slash")
    return value


def check_publication_params(args: argparse.Namespace) -> int:
    """Read actual config and planned/existing front matter before research/build.

    Intentionally limited to this site's date/title route and static post
    permalinks. Unknown routing is BLOCKED, never a guessed category URL.
    """
    failures: list[str] = []
    files: dict[str, dict[str, object]] = {}
    resolved: dict[str, object] = {}
    checked: list[str] = []

    def require(condition: bool, message: str) -> None:
        if not condition:
            raise ValueError(message)

    def read(path: Path, label: str, *, front: bool = False) -> dict:
        data, _ = _read_stable_bytes(str(path))
        files[str(path)] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
        text = data.decode("utf-8")
        if front:
            text = _front_matter(text)
            require(text is not None, f"{label}: byte-zero LF front matter delimiters required")
        return _yaml_mapping(text, label)

    try:
        repo = _publication_path(args.blog_repo, "blog-repo")
        require(repo.is_dir(), "blog-repo: directory missing")
        config_path = _publication_path("_config.yml", "site config", repo)
        config = read(config_path, "site config")
        require(config.get("permalink") == "/:year/:month/:day/:title.html",
                "site config: unsupported permalink; require /:year/:month/:day/:title.html, do not guess URL")
        require(config.get("timezone") == "Asia/Shanghai", "site config: unsupported timezone (expected Asia/Shanghai)")
        require(not any(key in config for key in ("source", "collections", "collections_dir")),
                "site config: custom source/collection routing is unsupported")
        defaults = config.get("defaults", [])
        require(isinstance(defaults, list), "site config: defaults must be a list")
        for entry in defaults:
            require(isinstance(entry, dict) and isinstance(entry.get("values"), dict),
                    "site config: unsupported defaults structure")
            require(not set(entry["values"]) & {"permalink", "date", "slug", "categories", "category", "bucket", "header", "published"},
                    "site config: routing/publication metadata defaults unsupported; use explicit front matter")
        origin = config.get("url")
        require(isinstance(origin, str), "site config: url required")
        url = urlsplit(origin)
        require(url.scheme in ("http", "https") and bool(url.hostname) and url.username is None
                and url.password is None and not url.query and not url.fragment and url.path in ("", "/")
                and not re.search(r"[\s\\]", origin), "site config: url must be an HTTP(S) origin without credentials/path/query")
        require(origin in (f"{url.scheme}://{url.netloc}", f"{url.scheme}://{url.netloc}/")
                and re.fullmatch(r"[A-Za-z0-9.-]+(?::[0-9]+)?", url.netloc) is not None,
                "site config: noncanonical origin/hostname")
        _ = url.port  # validate port syntax/range without network access
        origin = origin.rstrip("/")
        baseurl = config.get("baseurl", "")
        if baseurl != "":
            baseurl = _url_path(baseurl, "baseurl", directory=True)
        checked.append("actual-site-config")

        blog = _publication_path(args.blog, "blog", repo)
        require(blog.parent == repo / "_posts", "blog: must be directly within _posts (no nested category directories)")
        require(blog.name == args.expected_basename, "blog: basename differs from explicit expected-basename")
        match = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})-([a-z0-9]+(?:-[a-z0-9]+)*)\.md", blog.name)
        require(match is not None, "blog: require YYYY-MM-DD-lowercase-ascii-slug.md")
        year, month, day, slug = match.groups()
        post_date = f"{year}-{month}-{day}"
        datetime.strptime(post_date, "%Y-%m-%d")
        metadata_path = _publication_path(args.front_matter, "front-matter")
        meta = read(metadata_path, "front matter", front=True)
        mode = "planned"
        if blog.exists():
            actual = read(blog, "existing blog", front=True)
            require(actual == meta, "existing blog: front matter differs from supplied candidate")
            mode = "existing"
        require(meta.get("layout") == "single", "front matter: explicit layout: single required")
        require(isinstance(meta.get("title"), str) and bool(meta["title"].strip()), "front matter: nonempty title required")
        require("slug" not in meta and "category" not in meta, "front matter: slug/category overrides unsupported")
        require(meta.get("published", True) is True, "front matter: published must not disable publication")
        date_text = str(meta.get("date", ""))
        require(re.fullmatch(re.escape(post_date) + r"(?:[ T]\d{2}:\d{2}:\d{2} ?(?:\+0800|\+08:00))?", date_text) is not None,
                "front matter: date must match basename day, with +0800/+08:00 if time is present")
        datetime.fromisoformat(date_text.replace(" +", "+").replace("+0800", "+08:00"))
        categories = meta.get("categories")
        require(isinstance(categories, list) and bool(categories)
                and all(isinstance(item, str) and bool(item.strip()) for item in categories)
                and categories == args.category and len(set(categories)) == len(categories),
                "front matter: categories must exactly equal repeated --category values (ordered, unique)")
        checked.extend(["basename-and-front-matter", "categories"])

        header = meta.get("header")
        require(isinstance(header, dict), "front matter: header mapping required")
        overlay = _url_path(header.get("overlay_image"), "header.overlay_image")
        require(overlay == args.header_path, "header.overlay_image differs from --header-path")
        require(re.fullmatch(r"/assets/images/posts/" + re.escape(post_date)
                             + r"-[a-z0-9]+(?:-[a-z0-9]+)*\.(?:png|jpg|jpeg|webp)", overlay) is not None,
                "header: require /assets/images/posts/<post-date>-<name>.<png|jpg|jpeg|webp>")
        image = _publication_path(overlay.lstrip("/"), "header", repo)
        checked.append("header-path")

        bucket = meta.get("bucket")
        require(bucket == args.bucket and ("bucket" in meta) == (args.bucket is not None),
                "front matter: bucket differs from --bucket (do not infer series from title)")
        if bucket is not None:
            require(isinstance(bucket, str) and re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", bucket) is not None,
                    "front matter: invalid bucket")
            require(bool(args.bucket_page), "explicit bucket requires --bucket-page as actual local column metadata evidence")
            page_path = _publication_path(args.bucket_page, "bucket-page", repo)
            require(not any(part.startswith(("_", ".")) for part in page_path.relative_to(repo).parts),
                    "bucket-page: require a public source page, not generated/private metadata")
            page = read(page_path, "bucket page", front=True)
            require(page.get("layout") == "list" and page.get("list_kind") == "weekly" and page.get("bucket") == bucket
                    and page.get("published", True) is True, "bucket page: require matching published layout:list/list_kind:weekly/bucket")
            _url_path(page.get("permalink"), "bucket page permalink")
            checked.append("bucket-column-metadata")
        else:
            require(args.bucket_page is None, "bucket-page requires explicit --bucket")

        article_path = f"/{year}/{month}/{day}/{slug}.html"
        route_source = "site-date-title-permalink"
        if "permalink" in meta:
            article_path = _url_path(meta["permalink"], "post permalink")
            require(article_path.endswith((".html", "/")), "post permalink: require static .html or directory URL")
            route_source = "post-static-permalink"
        expected_url = origin + baseurl + article_path
        image_url = origin + baseurl + overlay
        resolved.update({"blog": str(blog), "input_mode": mode, "basename": blog.name,
                         "config_permalink": config["permalink"], "route_source": route_source,
                         "article_path": article_path, "article_url": expected_url,
                         "rendered_relative_path": article_path.lstrip("/") + ("index.html" if article_path.endswith("/") else ""),
                         "header_path": overlay, "header_file": str(image), "image_url": image_url,
                         "categories": categories, "bucket": bucket, "site_url": origin, "baseurl": baseurl})
        require(args.article_url == expected_url, f"article-url mismatch: expected {expected_url} (categories are not URL prefixes)")
        require(args.image_url == image_url, f"image-url mismatch: expected {image_url}")
        checked.append("declared-public-urls")
        for path, evidence in files.items():
            current, _ = _read_stable_bytes(path)
            require(hashlib.sha256(current).hexdigest() == evidence["sha256"], f"input changed during parameter check: {path}")
    except UnicodeError:
        failures.append("UTF-8 required for config/front matter/bucket page")
    except (OSError, ValueError, RuntimeError) as exc:
        failures.append(str(exc))
    ok = not failures
    print(json.dumps({
        "schema_version": 1, "status": "PUBLICATION_PARAMS_OK" if ok else "PUBLICATION_PARAMS_BLOCKED",
        "scope": "local-publication-parameters", "ok": ok, "read_only": True,
        "semantic_review_performed": False, "publication_verified": False,
        "checked": checked, "failures": failures, "resolved": resolved, "files": files,
        "remaining_checks": ["theme-parameter-authority", "actual-post-and-image-source-prebuild",
                             "plugin-runtime-and-build-routing", "real-build-start-end-exit-zero", "postbuild-local-checklist",
                             "research-and-article-semantics", "git-remote-both-repos", "http-body-and-image-current-version"],
    }, ensure_ascii=False, sort_keys=True))
    return 0 if ok else 1


def check_publication(args: argparse.Namespace) -> int:
    """Read-only local source/build gate. Never executes build, Git or HTTP."""
    phase = args.phase
    failures: list[str] = []
    checked: list[str] = []
    observed: dict[Path, tuple[str, int]] = {}

    def read_file(path: Path, label: str, *, text_source: bool = False) -> bytes:
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"{label}: nonempty regular file required: {path}")
        stamp = path.stat().st_mtime_ns
        data = path.read_bytes()
        if not data:
            raise ValueError(f"{label}: empty file: {path}")
        if stamp != path.stat().st_mtime_ns:
            raise ValueError(f"{label}: changed during read")
        if text_source:
            data.decode("utf-8")
            eof = _eof_issue(data)
            if eof is not None:
                message, offset = eof
                location = _text_location(data, offset)
                raise ValueError(f"{label}: {message} at line {location['line']} byte {location['byte_offset']}")
        observed[path] = (hashlib.sha256(data).hexdigest(), stamp)
        return data

    def require(condition: bool, message: str) -> None:
        if not condition:
            raise ValueError(message)

    try:
        require(bool(args.run_id.strip()), "run_id must not be blank")
        require(datetime.strptime(args.index_date, "%Y-%m-%d").date().isoformat() == args.index_date,
                "index-date must be YYYY-MM-DD")
        archive = _publication_path(args.archive_repo, "archive-repo")
        repo = _publication_path(args.blog_repo, "blog-repo")
        require(not archive.is_relative_to(repo) and not repo.is_relative_to(archive),
                "archive-repo and blog-repo must be distinct non-overlapping roots")
        for label, path in (("archive-repo", archive), ("blog-repo", repo)):
            require(path.is_dir(), f"{label}: directory missing: {path}")

        site = None
        started = None
        if phase == "postbuild":
            try:
                started = datetime.fromisoformat(args.build_started_at.replace("Z", "+00:00"))
                require(started.tzinfo is not None and started <= datetime.now(timezone.utc),
                        "build-started-at must have a timezone and not be in the future")
            except ValueError as exc:
                raise ValueError("build-started-at: timezone-aware ISO-8601 timestamp required, not in future") from exc
            site = _publication_path(args.site, "site")
            require(site.is_dir(), f"site: directory missing: {site}")

        report = _publication_path(args.report, "report")
        article = _publication_path(args.article, "article")
        report_bytes = read_file(report, "report", text_source=True)
        article_bytes = read_file(article, "article", text_source=True)
        expected = {"status": "PASS", "run_id": args.run_id, "source_sha256": observed[report][0]}
        for label, raw, fields in (
            ("research.done", args.research_done, expected),
            ("article.done", args.article_done, {**expected, "article_sha256": observed[article][0]}),
        ):
            path = _publication_path(raw, label)
            _check_done(read_file(path, label).decode("utf-8"), label, fields)
            checked.append(label)

        target = _publication_path(args.archive_file, "archive-file", archive)
        target_bytes = read_file(target, "archive-file")
        require(target_bytes == report_bytes, "archive bytes differ from frozen report")
        archive_eof = _eof_issue(target_bytes)
        require(archive_eof is None, f"archive-file: {archive_eof[0]}" if archive_eof else "")
        checked.append("archive-bytes")
        index = _publication_path("INDEX.md", "INDEX", archive)
        require(_has_index_entry(read_file(index, "INDEX", text_source=True).decode("utf-8"), args.index_date,
                                 target.relative_to(archive).as_posix()),
                "INDEX entry missing in expected date table")
        checked.append("archive-index")

        blog = _publication_path(args.blog, "blog", repo)
        blog_bytes = read_file(blog, "blog", text_source=True)
        blog_text = blog_bytes.decode("utf-8")
        front_matter = _front_matter(blog_text)
        require(front_matter is not None, "blog: invalid front matter")
        body = blog_bytes[blog_bytes.index(b"\n---\n", 4) + 5:]
        require(body == article_bytes, "blog body differs from frozen article (only front matter may be added)")
        checked.append("blog-body")
        overlay = _overlay_path(front_matter)
        require(overlay is not None and overlay.startswith("/assets/images/posts/"),
                "blog: invalid overlay image path")
        image = _publication_path(args.image, "frozen image")
        frozen_image = read_file(image, "frozen image")
        copied_image = _publication_path(overlay.lstrip("/"), "blog image", repo)
        require(read_file(copied_image, "blog image") == frozen_image,
                "blog image bytes differ from frozen image")
        checked.append("blog-image")

        if phase == "prebuild":
            validator_output = io.StringIO()
            with contextlib.redirect_stdout(validator_output):
                blog_code = validate_blog_post(argparse.Namespace(repo=str(repo), blog=str(blog), site=None))
            require(blog_code == 0, validator_output.getvalue().strip())
            checked.append("blog-validator-source")

        if phase == "postbuild":
            assert site is not None and started is not None
            rendered_failures: list[str] = []
            rendered = _rendered_blog_path(site, blog, front_matter, rendered_failures)
            require(not rendered_failures, "; ".join(rendered_failures))
            rendered = _publication_path(str(rendered), "rendered HTML", site)
            html = read_file(rendered, "rendered HTML").decode("utf-8")
            built_image = _publication_path(overlay.lstrip("/"), "built image", site)
            require(read_file(built_image, "built image") == frozen_image,
                    "built image bytes differ from frozen image")
            latest_input = max(observed[p][1] for p in (report, article, blog, image, copied_image))
            require(observed[rendered][1] >= max(int(started.timestamp() * 1_000_000_000), latest_input),
                    "build freshness: rendered HTML predates build start or a publication input")
            parser = _VisibleHTMLText()
            parser.feed(html)
            parser.close()
            visible = " ".join("".join(parser.parts).split())
            source_text = " ".join(article_bytes.decode("utf-8").split())
            for probe in args.html_text:
                probe = " ".join(probe.split())
                require(bool(probe) and probe in source_text,
                        "article probe must be nonempty and present in frozen article")
                require(probe in visible, f"HTML text missing from current build: {probe}")
            validator_output = io.StringIO()
            with contextlib.redirect_stdout(validator_output):
                blog_code = validate_blog_post(argparse.Namespace(repo=str(repo), blog=str(blog), site=str(site)))
            require(blog_code == 0, validator_output.getvalue().strip())
            checked.append("blog-validator-and-current-build")

        for path, (digest, stamp) in observed.items():
            require(not path.is_symlink() and path.is_file() and path.stat().st_mtime_ns == stamp
                    and _sha256(path) == digest, f"input changed during checklist: {path}")
    except UnicodeError:
        failures.append("UTF-8 text required for done, INDEX, report, article, blog and HTML")
    except (OSError, ValueError, RuntimeError) as exc:
        failures.append(str(exc))

    ok = not failures
    if phase == "prebuild":
        status = "LOCAL_SOURCE_CHECKLIST_PASS" if ok else "LOCAL_SOURCE_CHECKLIST_BLOCKED"
        remaining = ["jekyll-build-execution-exit-zero", "postbuild-local-checklist",
                     "research-and-article-semantics", "git-remote-both-repos",
                     "http-body-and-image-current-version"]
    else:
        status = "LOCAL_CHECKLIST_PASS" if ok else "LOCAL_CHECKLIST_BLOCKED"
        remaining = ["research-and-article-semantics", "build-execution-exit-zero",
                     "git-remote-both-repos", "http-body-and-image-current-version"]
    print(json.dumps({
        "status": status, "phase": phase, "ok": ok,
        "scope": "local-publication-checklist", "run_id": args.run_id,
        "publication_verified": False, "checked": checked, "failures": failures,
        "files": {str(path): {"sha256": digest, "mtime_ns": stamp}
                  for path, (digest, stamp) in observed.items()},
        "remaining_checks": remaining,
    }, ensure_ascii=False, sort_keys=True))
    return 0 if ok else 1

def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Weekly cron deterministic helpers")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("insert-index", help="insert one row into openclaw_daily_file/INDEX.md")
    p.add_argument("--repo", required=True)
    p.add_argument("--date", required=True)
    p.add_argument("--file", required=True)
    p.add_argument("--dir", required=True)
    p.add_argument("--author", required=True)
    p.add_argument("--title", required=True)
    p.add_argument("--summary", required=True)
    p.set_defaults(func=insert_index)

    p = sub.add_parser("insert-index-auto", help="derive title/date/summary from report and insert INDEX row")
    p.add_argument("--repo", required=True)
    p.add_argument("--file", required=True)
    p.add_argument("--dir", required=True)
    p.add_argument("--author", required=True)
    p.add_argument("--date")
    p.add_argument("--title")
    p.add_argument("--summary")
    p.set_defaults(func=insert_index_auto)

    p = sub.add_parser(
        "check-inputs",
        help="read-only bounded validation for candidate frozen UTF-8 text files",
        description="Safely inspect regular non-symlink files without writing or semantic attestation. "
                    "All files are checked and reported in one JSON result.",
    )
    p.add_argument("--file", action="append", required=True,
                   help="repeat absolute paths; nonempty UTF-8, LF-only, one final LF, no Git-default whitespace errors on any line")
    p.set_defaults(func=check_inputs)

    p = sub.add_parser(
        "check-publication-params", help="read-only startup check of actual site config and proposed publication metadata",
        description="Inspect _config.yml, candidate front matter and explicit theme parameters, without build/Git/HTTP. "
                    "Supports this site's date/title route or a static post permalink; unsupported routing blocks. "
                    "PyYAML is required only for this command. Exit 0 is parameter consistency, not publication proof.",
        epilog="A planned post/image need not exist. If the post exists its front matter must equal the candidate. "
               "Recheck actual sources before build. Bucket pages prove local metadata consistency, not Liquid execution. "
               "No additional config files, environment overrides, plugin routing or generated output are evaluated.",
    )
    p.add_argument("--blog-repo", required=True, help="absolute site source root; reads its actual _config.yml")
    p.add_argument("--blog", required=True, help="planned or existing post directly in _posts; root-relative or absolute")
    p.add_argument("--front-matter", required=True, help="absolute UTF-8 LF candidate wrapper or actual post with byte-zero --- delimiters")
    p.add_argument("--expected-basename", required=True, help="exact dated .md basename from the theme contract (not inferred from title)")
    p.add_argument("--header-path", required=True, help="declared /assets/images/posts/<date>-<name> image path")
    p.add_argument("--article-url", required=True, help="declared full public article URL, compared with actual config")
    p.add_argument("--image-url", required=True, help="declared full public header URL")
    p.add_argument("--category", action="append", required=True, help="repeat expected categories in front matter order")
    p.add_argument("--bucket", help="explicit theme bucket when applicable; omission requires absent bucket metadata")
    p.add_argument("--bucket-page", help="actual public source page inside site root with matching weekly bucket metadata")
    p.set_defaults(func=check_publication_params)

    p = sub.add_parser("validate-startup-weekly", help="validate startup weekly report/blog before commit")
    p.add_argument("--report", required=True)
    p.add_argument("--blog", required=True)
    p.add_argument("--image")
    p.set_defaults(func=validate_startup_weekly)

    p = sub.add_parser("validate-blog-post", help="validate Jekyll front matter, header image, and optional built HTML")
    p.add_argument("--repo", required=True)
    p.add_argument("--blog", required=True)
    p.add_argument("--site")
    p.set_defaults(func=validate_blog_post)

    p = sub.add_parser(
        "check-publication", help="read-only dual-repository LOCAL publication checklist (not final publication proof)",
        description="Check local handoffs, archive/INDEX and blog/image sources; postbuild also checks "
                    "one specified current build. Does not execute build, Git, HTTP, copy, commit, push "
                    "or delivery. Exit 0 is LOCAL_SOURCE_CHECKLIST_PASS (prebuild) or "
                    "LOCAL_CHECKLIST_PASS (postbuild); exit 1 is blocked.",
        epilog="Done files: unindented, unique status: PASS, run_id: VALUE, source_sha256: REPORT_SHA256; "
               "article.done also needs article_sha256: ARTICLE_SHA256. BLOCKED anywhere in a done is rejected. "
               "Other fields (including delivery/native status) are not publication proof. "
               "Continue with existing reliable_cron.py check-git --verify-remote for BOTH repos, "
               "check-http for body/image plus current-version checks, build exit evidence and semantic review. "
               "No audit PASS or saved helper-result string is accepted as verification.",
    )
    p.add_argument("--phase", choices=("prebuild", "postbuild"), default="postbuild",
                   help="prebuild checks frozen sources only; default postbuild preserves legacy behavior")
    p.add_argument("--run-id", required=True, help="expected logical run ID in both done files")
    p.add_argument("--research-done", required=True, help="absolute path to current research acceptance marker")
    p.add_argument("--article-done", required=True, help="absolute path to current article acceptance marker")
    p.add_argument("--report", required=True, help="absolute frozen research master; SHA-256 binds both done files")
    p.add_argument("--article", required=True, help="absolute frozen article; must equal blog body bytes after front matter")
    p.add_argument("--archive-repo", required=True, help="absolute research archive root, distinct from blog root")
    p.add_argument("--archive-file", required=True, help="archive target within root; must equal ALL frozen report bytes")
    p.add_argument("--index-date", required=True, help="YYYY-MM-DD section containing the exact INDEX.md table link")
    p.add_argument("--blog-repo", required=True, help="absolute blog repository root")
    p.add_argument("--blog", required=True, help="blog post within blog root (absolute or root-relative)")
    p.add_argument("--image", required=True, help="absolute frozen header image; source and built copies must match bytes")
    p.add_argument("--site", help="postbuild only: absolute CURRENT build root; HTML path derives from post/permalink")
    p.add_argument("--build-started-at", help="postbuild only: recorded build start, ISO-8601 with timezone; HTML mtime must postdate it and inputs")
    p.add_argument("--html-text", action="append", help="postbuild only: repeat distinctive title/content probes from frozen article")
    p.set_defaults(func=check_publication)

    args = parser.parse_args(argv)
    if args.cmd == "check-publication" and args.phase == "postbuild":
        missing = [flag for flag, value in (("--site", args.site),
                                             ("--build-started-at", args.build_started_at),
                                             ("--html-text", args.html_text)) if not value]
        if missing:
            parser.error("check-publication postbuild requires " + ", ".join(missing))
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
