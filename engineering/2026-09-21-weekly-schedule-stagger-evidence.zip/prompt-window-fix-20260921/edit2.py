#!/usr/bin/env python3
"""同步 _reader-positioning.md 排程对照表（2 行）。"""
import sys, hashlib, difflib, os

P = "/root/.openclaw/workspace/shared/prompts/_reader-positioning.md"
D = "/root/.openclaw/workspace/shared/artifacts/prompt-window-fix-20260921"

EDITS = [
    ("| 中国武汉光谷资讯周报 | 周一 12:00 | R3（区域） | R4 |",
     "| 中国武汉光谷资讯周报 | 周一 15:00 | R3（区域） | R4 |"),
    ("| 全球 AI 动态周报 | 周一 14:00 | R1（公司层） | R4 |",
     "| 全球 AI 动态周报 | 周五 15:00 | R1（公司层） | R4 |"),
]

if sys.argv[1] == "apply":
    txt = open(P, encoding="utf-8").read()
    open(os.path.join(D, "_reader-positioning.md.before"), "w", encoding="utf-8").write(txt)
    for old, new in EDITS:
        n = txt.count(old)
        assert n == 1, f"期望 1 处，实际 {n}: {old[:60]}"
        txt = txt.replace(old, new)
    open(P, "w", encoding="utf-8").write(txt)
    print(f"  ✅ _reader-positioning.md: 替换 {len(EDITS)} 处")

elif sys.argv[1] == "report":
    after = open(P, encoding="utf-8").read()
    before = open(os.path.join(D, "_reader-positioning.md.before"), encoding="utf-8").read()
    open(os.path.join(D, "_reader-positioning.md.after"), "w", encoding="utf-8").write(after)
    print(f"  SHA256: {hashlib.sha256(before.encode()).hexdigest()[:16]} → "
          f"{hashlib.sha256(after.encode()).hexdigest()[:16]}")
    lb, la = before.splitlines(), after.splitlines()
    print(f"  行数: {len(lb)} → {len(la)}")
    d = list(difflib.unified_diff(lb, la, "before", "after", lineterm="", n=0))
    for x in d[2:]:
        print("   " + x[:170])
