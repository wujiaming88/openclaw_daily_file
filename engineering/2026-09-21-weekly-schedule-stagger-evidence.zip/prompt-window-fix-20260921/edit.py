#!/usr/bin/env python3
"""窗口规则修正：AI动态随触发日改到周五；光谷仅同步文案。

最小化改动：只替换必要的 5 行，不触碰其他内容。
"""
import sys, shutil, hashlib, os

P = "/root/.openclaw/workspace/shared/prompts"
D = "/root/.openclaw/workspace/shared/artifacts/prompt-window-fix-20260921"

EDITS = {
    "weekly-ai-report.md": [
        # 标题：触发日
        ("# 全球 AI 动态周报 — 定时任务 Prompt（每周一 14:00 触发）",
         "# 全球 AI 动态周报 — 定时任务 Prompt（每周五 15:00 触发）"),
        # 窗口规则：镜像 AI+产业 的周五口径
        ("2. 本期周报覆盖区间 = **上周一 00:00 → 上周日 24:00（上海时区）的完整自然周**（周一为一周之首，ISO 8601 口径）。",
         '2. 本期周报覆盖区间 = **上周五 00:00 → 本周四 24:00（上海时区）的完整一周**。'),
        ("  - 任务在**周一 14:00**触发，所以覆盖刚结束的完整一周，勿把本周算进去。",
         '  - 任务在**周五 15:00**触发，"上周五到昨天（本周四）"正好是刚结束的完整一周。'),
    ],
    "weekly-guanggu-report.md": [
        ("# 中国武汉光谷资讯周报 — 定时任务 Prompt（每周一 12:00 触发）",
         "# 中国武汉光谷资讯周报 — 定时任务 Prompt（每周一 15:00 触发）"),
        ("  - 任务在周一 12:00 触发，所以覆盖刚结束的完整自然周，绝不把触发当天的新消息混入本期。",
         "  - 任务在周一 15:00 触发，所以覆盖刚结束的完整自然周，绝不把触发当天的新消息混入本期。"),
    ],
}

if sys.argv[1] == "apply":
    for fn, pairs in EDITS.items():
        path = os.path.join(P, fn)
        txt = open(path, encoding="utf-8").read()
        for old, new in pairs:
            n = txt.count(old)
            assert n == 1, f"{fn}: 期望 1 处，实际 {n} 处 → {old[:50]}"
            txt = txt.replace(old, new)
        open(path, "w", encoding="utf-8").write(txt)
        print(f"  ✅ {fn}: 替换 {len(pairs)} 处")

elif sys.argv[1] == "report":
    for fn in EDITS:
        path = os.path.join(P, fn)
        after = open(path, encoding="utf-8").read()
        before = open(os.path.join(D, fn + ".before"), encoding="utf-8").read()
        open(os.path.join(D, fn + ".after"), "w", encoding="utf-8").write(after)
        hb = hashlib.sha256(before.encode()).hexdigest()
        ha = hashlib.sha256(after.encode()).hexdigest()
        lb = before.splitlines()
        la = after.splitlines()
        print(f"\n{'='*72}\n【{fn}】")
        print(f"  行数: {len(lb)} → {len(la)}")
        print(f"  SHA256: {hb[:16]} → {ha[:16]}")
        # 逐行差异
        import difflib
        d = list(difflib.unified_diff(lb, la, "before", "after", lineterm="", n=0))
        adds = [x for x in d if x.startswith("+") and not x.startswith("+++")]
        dels = [x for x in d if x.startswith("-") and not x.startswith("---")]
        print(f"  新增行 {len(adds)} / 删除行 {len(dels)}")
        for x in d[2:]:
            print("   " + x[:180])
        # 纯增量校验：删除行必须全部是「被替换的旧版本行」
        print(f"  → 行数不变且增删相等: {'✅' if len(lb)==len(la) and len(adds)==len(dels) else '⚠️ 需人工确认'}")
