before/  SKILL.md、helper-contract.md 改前全文
after/   SKILL.md、helper-contract.md 改后全文
diff/    unified diff（SKILL.md 3 hunk；helper-contract.md 1 hunk）
evidence/SHA256.txt        上述文件的哈希
evidence/cron-{before,after}.json  调度快照（已脱敏：投递收件人替换为 <redacted>）
evidence/cron-drift-proof.txt      零漂移机器证明

零漂移证明：原始（未脱敏）快照改前/改后 SHA256 完全相同
  a2bc4aabf868755cbf9eb8af3bbb62bd3cbf75ac210ba7f829f3c71cf2a71d9b  （改前 = 改后）
脱敏副本经同一替换后仍逐字节相同，故结构比对结论不受脱敏影响。

结论：正文 SHA 核验通过；调度零漂移；回归测试 3/3 通过。
不含凭据、令牌或投递收件人（收件人标识已脱敏）。
